# Experiment logs (Data S1 payload)

Every number, table, and figure in the manuscript is generated from the
files in this directory by `scripts/make_figs_tables.py`. Columns are
written by `src/cords/run_experiments.py`; policy keys are the internal
uppercase identifiers (`CORDS` = the CoRDS method, `DET`, `P90`, `SAA`,
`ORACLE`, `ATC`, `ATCS`, `FIFO`, `SPT`, `EDD`, ablations `NOML`,
`NOCONF`, `NOCCG`, `FIXG`).

| File | Contents |
| --- | --- |
| `bench_main.csv` | window certification benchmark: one row per (window, method); nominal cost, audited worst case on the CoRDS set, realized cost, exactness flag of the audit adversary |
| `bench_alpha.csv` | miscoverage sweep (alpha in {0.05, 0.1, 0.2}) on the most contended windows |
| `bench_lambda.csv` | lambda blend sweep tracing the nominal/worst-case frontier |
| `main_loop.csv` | closed loop, base configuration: per (policy, seed) totals; `solver_s` is the **episode total** solver time, `n_replans` the number of replanning events (the paper reports `solver_s / n_replans`) |
| `drift_loop.csv` | closed loop under the warm-to-cold covariate shift |
| `sens_loop.csv` | sensitivity grid (setup scaling, failure intensity, load/due tightness) |
| `scale.csv` | solver stress test on an overloaded instance; per-window solve statistics |
| `shock_loop.csv` | closed loop under correlated HVAC-type shocks (v1.1); `coverage`, `shock_coverage`, `shock_ops` |
| `s2noise_loop.csv` | stage-2 assembly noise sensitivity (v1.1) |
| `adv_gap.csv`, `adv_gap_scale.csv` | exact vs greedy adversary values on identical plans; first-decision agreement (v1.1) |
| `bench_saa.csv` | SAA with 12/24 scenarios under the common audit (v1.1) |
| `rq1_uq.csv`, `rq1_online.csv` | conformal calibration and online-adaptation summaries |
| `uq_cell.pkl`, `uq_shift.pkl` | fitted CQR model bundles (by-cell split; warm-to-cold shift split) |
| `windows.pkl.gz`, `scale_w*.pkl.gz` | frozen decision-window snapshots used by the benchmark |
| `exp.log` | timestamped stage log of the original runs (provenance) |

Deleting this directory and re-running `scripts/run_experiments.py all`
reproduces every CSV from scratch (several CPU-hours; the driver is
resumable at the unit level).
