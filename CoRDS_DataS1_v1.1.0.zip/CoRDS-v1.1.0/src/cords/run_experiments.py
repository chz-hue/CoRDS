"""Staged experiment driver. Writes incremental CSVs to ../results and a
progress log; safe to re-run (skips finished stages by file existence)."""
import gzip
import os
import pickle
import sys
import time
import traceback
import numpy as np
from cords.paths import RESULTS_DIR, ensure_dirs
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cords.simulator import fit_uq, gen_instance, run_policy   # noqa: E402
from cords.bench import collect_windows, bench                  # noqa: E402
from cords.ml_uq import gamma_budget                              # noqa: E402

R = str(RESULTS_DIR)
LOG = open(f"{R}/exp.log", "a", buffering=1)


def log(msg):
    LOG.write(f"[{time.strftime('%H:%M:%S')}] {msg}\n")


def stage(name):
    def deco(fn):
        def run():
            flag = f"{R}/.done_{name}"
            if os.path.exists(flag):
                log(f"{name}: skip (done)")
                return
            t0 = time.time()
            log(f"{name}: start")
            try:
                fn()
                open(flag, "w").write("ok")
                log(f"{name}: DONE in {time.time()-t0:.0f}s")
            except Exception:
                log(f"{name}: FAILED\n" + traceback.format_exc())
        return run
    return deco


def resume(csvpath, keycols):
    import os as _os
    if not _os.path.exists(csvpath):
        return [], set()
    df = pd.read_csv(csvpath)
    rows = df.to_dict("records")
    done = set(tuple(r[c] for c in keycols) for r in rows)
    return rows, done


def get_uq(split):
    p = f"{R}/uq_{split}.pkl"
    if os.path.exists(p):
        return pickle.load(open(p, "rb"))
    uq = fit_uq(split)
    pickle.dump(uq, open(p, "wb"))
    return uq


# ------------------------------------------------------------------ S1
POLICIES = ["FIFO", "SPT", "EDD", "ATC", "ATCS",
            "DET", "P90", "SAA", "CORDS", "ORACLE"]


@stage("main_loop")
def s1():
    uq = get_uq("cell")
    rows, done = resume(f"{R}/main_loop.csv", ("seed", "policy"))
    for sd in range(1, 15):
        inst = None
        for pol in POLICIES:
            if (sd, pol) in done:
                continue
            if inst is None:
                inst = gen_instance(sd, uq)
            t0 = time.time()
            r = run_policy(inst, pol, uq)
            r["wall_s"] = time.time() - t0
            rows.append(r)
            pd.DataFrame(rows).to_csv(f"{R}/main_loop.csv", index=False)
        log(f"main_loop: seed {sd} done")


# ------------------------------------------------------------------ S2
@stage("windows")
def s2():
    uq = get_uq("cell")
    snaps, seen = [], set()
    part = f"{R}/windows_part.pkl.gz"
    if os.path.exists(part):
        with gzip.open(part, "rb") as f:
            snaps = pickle.load(f)
        seen = set(s["seed"] for s in snaps)
        log(f"windows: resume with {len(snaps)} from seeds {sorted(seen)}")
    for sd in range(501, 509):
        if sd in seen:
            continue
        snaps.extend(collect_windows(uq, seeds=[sd], cap_per_inst=22))
        with gzip.open(part, "wb") as f:
            pickle.dump(snaps, f)
        log(f"windows: seed {sd} done ({len(snaps)} total)")
    with gzip.open(f"{R}/windows.pkl.gz", "wb") as f:
        pickle.dump(snaps, f)
    log(f"windows: {len(snaps)} collected")


def load_windows():
    with gzip.open(f"{R}/windows.pkl.gz", "rb") as f:
        return pickle.load(f)


# ------------------------------------------------------------------ S3
@stage("bench_main")
def s3():
    uq = get_uq("cell")
    snaps = load_windows()
    done_w = set()
    old = []
    if os.path.exists(f"{R}/bench_main.csv"):
        df0 = pd.read_csv(f"{R}/bench_main.csv")
        cnt = df0.groupby("w").method.count()
        done_w = set(cnt[cnt >= 9].index)
        old = [df0[df0.w.isin(done_w)]]
        log(f"bench_main: resume, {len(done_w)} windows done")
    todo = [s for i, s in enumerate(snaps) if i not in done_w]
    idx = [i for i, s in enumerate(snaps) if i not in done_w]
    for j, (i, s) in enumerate(zip(idx, todo)):
        d = bench([s], uq, tl=1.2, tag="main")
        d["w"] = i
        old.append(d)
        pd.concat(old).to_csv(f"{R}/bench_main.csv", index=False)
        if (j + 1) % 20 == 0:
            log(f"bench_main: {j+1}/{len(todo)}")


@stage("bench_alpha")
def s3b():
    uq = get_uq("cell")
    snaps = load_windows()
    snaps = sorted(snaps, key=lambda s: -len(s["win"].uncertain_units()))[:48]
    log(f"bench_alpha: {len(snaps)} contended windows")
    out = f"{R}/bench_alpha.csv"
    olds, done = [], set()
    if os.path.exists(out):
        df0 = pd.read_csv(out)
        cnt = df0.groupby(["tag", "w"]).method.count()
        done = set(cnt[cnt >= 3].index)
        olds = [df0[[(t, w) in done for t, w in zip(df0.tag, df0.w)]]]
        log(f"bench_alpha: resume {len(done)} (tag,w) done")
    for a in (0.05, 0.2):
        for i, s in enumerate(snaps):
            if (f"a{a}", i) in done:
                continue
            d = bench([s], uq, alpha=a, tl=1.2,
                      methods=("DET", "P90", "CORDS"), tag=f"a{a}")
            d["w"] = i
            olds.append(d)
            pd.concat(olds).to_csv(out, index=False)


@stage("bench_lambda")
def s3c():
    uq = get_uq("cell")
    snaps = load_windows()
    snaps = sorted(snaps, key=lambda s: -len(s["win"].uncertain_units()))[:32]
    log(f"bench_lambda: {len(snaps)} contended windows")
    out = f"{R}/bench_lambda.csv"
    olds, done = [], set()
    if os.path.exists(out):
        df0 = pd.read_csv(out)
        cnt = df0.groupby(["tag", "w"]).method.count()
        done = set(cnt[cnt >= 1].index)
        olds = [df0[[(t, w) in done for t, w in zip(df0.tag, df0.w)]]]
        log(f"bench_lambda: resume {len(done)} (tag,w) done")
    for lam in ((1, 0), (4, 1), (1, 4), (0, 1)):
        tg = f"lam{lam[0]}_{lam[1]}"
        for i, s in enumerate(snaps):
            if (tg, i) in done:
                continue
            d = bench([s], uq, tl=1.2, methods=("CORDS",), tag=tg, lam=lam)
            d["w"] = i
            olds.append(d)
            pd.concat(olds).to_csv(out, index=False)


# ------------------------------------------------------------------ S4
@stage("drift_loop")
def s4():
    uq = get_uq("shift")           # trained warm, test pool = cold cells
    med1 = float(np.median(uq["charge"]["pool"].y_duration_s)) / 60.0
    ia = med1 / (4 * 0.92)
    log(f"drift: cold pool median p1={med1:.0f}min -> ia={ia:.0f}")
    rows, done = resume(f"{R}/drift_loop.csv", ("seed", "policy"))
    for sd in range(601, 611):
        inst = None
        for pol in ["ATCS", "DET", "P90", "CORDS", "CORDS_online"]:
            if (sd, pol) in done:
                continue
            if inst is None:
                inst = gen_instance(sd, uq, dict(mean_ia=ia))
            r = run_policy(inst, pol, uq, dict(mean_ia=ia))
            rows.append(r)
            pd.DataFrame(rows).to_csv(f"{R}/drift_loop.csv", index=False)
        log(f"drift: seed {sd} done")


# ------------------------------------------------------------------ S5
@stage("sens_loop")
def s5():
    uq = get_uq("cell")
    grids = ([("su", dict(su_scale=s), p) for s in (0.0, 2.0)
              for p in ("ATCS", "DET", "CORDS")]
             + [("mtbf", dict(mtbf=m), p) for m in (1440.0, 1e18)
                for p in ("DET", "CORDS")]
             + [("load", dict(mean_ia=44.0, due_base=1.35), p)
                for p in ("DET", "P90", "CORDS")]
             + [("load", dict(mean_ia=58.0, due_base=1.7), p)
                for p in ("DET", "P90", "CORDS")])
    rows, done = resume(f"{R}/sens_loop.csv", ("seed", "policy", "tag"))
    for sd in range(701, 707):
        for tag, ov, pol in grids:
            t = tag + "_" + "_".join(f"{k}{v}" for k, v in ov.items())
            if (sd, pol, t) in done:
                continue
            inst = gen_instance(sd, uq, ov)
            r = run_policy(inst, pol, uq, ov)
            r["tag"] = t
            rows.append(r)
            pd.DataFrame(rows).to_csv(f"{R}/sens_loop.csv", index=False)
        log(f"sens: seed {sd} done")


# ------------------------------------------------------------------ S6
@stage("scale")
def s6():
    uq = get_uq("cell")
    rows, done = [], set()
    if os.path.exists(f"{R}/scale.csv"):
        df0 = pd.read_csv(f"{R}/scale.csv")
        rows = df0.to_dict("records")
        done = set(zip(df0.wcap, df0.idx))
        log(f"scale: resume, {len(done)} solves done")
    for wcap, sd in [(12, 801), (16, 802), (20, 803), (24, 804)]:
        cfg = dict(n_jobs=44, mean_ia=30.0, wcap=wcap, wcap_s1=wcap // 2)
        cachef = f"{R}/scale_w{wcap}.pkl.gz"
        if os.path.exists(cachef):
            with gzip.open(cachef, "rb") as f:
                snaps = pickle.load(f)
        else:
            snaps = collect_windows(uq, seeds=[sd], cfg=cfg, cap_per_inst=8)
            snaps = sorted(snaps, key=lambda s: -len(s["win"].ops))[:4]
            with gzip.open(cachef, "wb") as f:
                pickle.dump(snaps, f)
            log(f"scale: wcap {wcap} collected {len(snaps)}")
        for i, s in enumerate(snaps):
            if (wcap, i) in done:
                continue
            df = bench([s], uq, tl=3.0, methods=("CORDS",), tag=f"w{wcap}")
            for _, r in df.iterrows():
                rows.append(dict(wcap=wcap, idx=i, n_ops=r.n_ops,
                                 n_jobs=r.n_jobs, K=r.K, Gamma=r.Gamma,
                                 solve_s=r.solve_s, wc_exact=r.wc_exact))
            pd.DataFrame(rows).to_csv(f"{R}/scale.csv", index=False)
        log(f"scale: wcap {wcap} done")


# ------------------------------------------------------------------ S7
@stage("shock_loop")
def s7():
    """Correlated process shocks (HVAC-type): every formation duration is
    inflated by shock_factor while a shock is active."""
    uq = get_uq("cell")
    ov = dict(n_jobs=16, shock_rate_h=0.125, shock_dur=90.0,
              shock_factor=1.4, shock_stages=(0,))
    rows, done = resume(f"{R}/shock_loop.csv", ("seed", "policy"))
    for sd in range(801, 809):
        inst = None
        for pol in ["DET", "CORDS", "CORDS_online"]:
            if (sd, pol) in done:
                continue
            if inst is None:
                inst = gen_instance(sd, uq, ov)
            r_ = run_policy(inst, pol, uq, ov)
            r_["tag"] = "hvac"
            rows.append(r_)
            pd.DataFrame(rows).to_csv(f"{R}/shock_loop.csv", index=False)
        log(f"shock: seed {sd} done")


# ------------------------------------------------------------------ S8
@stage("s2noise_loop")
def s8():
    """Sensitivity to the (synthetic) stage-2 assembly noise amplitude."""
    uq = get_uq("cell")
    rows, done = resume(f"{R}/s2noise_loop.csv", ("seed", "policy", "tag"))
    for sd in range(701, 707):
        for nz in (0, 6, 30):
            ov = dict(s2_noise=nz)
            inst = None
            for pol in ["DET", "CORDS"]:
                t = f"s2noise{nz}"
                if (sd, pol, t) in done:
                    continue
                if inst is None:
                    inst = gen_instance(sd, uq, ov)
                r_ = run_policy(inst, pol, uq, ov)
                r_["tag"] = t
                rows.append(r_)
                pd.DataFrame(rows).to_csv(f"{R}/s2noise_loop.csv", index=False)
        log(f"s2noise: seed {sd} done")


# ------------------------------------------------------------------ S9
@stage("adv_gap")
def s9():
    """Exact vs greedy budget adversary on identical plans, and first-decision
    agreement between DET and CoRDS plans, over the frozen windows."""
    from math import comb
    from cords.sched_core import solve_master, ccg_solve, adversary
    snaps = load_windows()
    rows, done = resume(f"{R}/adv_gap.csv", ("w", "plan"))
    for i, snap in enumerate(snaps):
        if (i, "DET") in done and (i, "CORDS") in done:
            continue
        win = snap["win"]
        K = len(win.uncertain_units())
        G = gamma_budget(K, 0.1, 0.1) if K else 0
        tl = 1.0 * (1.0 + len(win.ops) / 18.0)
        nc = comb(K, G) if K else 0
        plans = {}
        plans["DET"] = solve_master(win, [win.scenario(set())], time_limit=tl,
                                    mode="single")
        plans["CORDS"], _ = ccg_solve(win, G, time_limit=tl, max_add=2)
        stage_of = {o["id"]: o["stage"] for o in win.ops}

        def first_ops(sol):
            out = {}
            for mid, seq in sol["order"].items():
                if seq:
                    out[mid] = seq[0]
            return out

        agree_all = agree_eol = np.nan
        if plans["DET"] is not None and plans["CORDS"] is not None:
            f_det, f_cor = first_ops(plans["DET"]), first_ops(plans["CORDS"])
            common = [m for m in f_det if m in f_cor]
            if common:
                agree_all = float(np.mean([f_det[m] == f_cor[m]
                                           for m in common]))
            eol = [m for m in common if stage_of.get(f_det[m]) == 2]
            if eol:
                agree_eol = float(np.mean([f_det[m] == f_cor[m] for m in eol]))
        for name, sol in plans.items():
            if sol is None or (i, name) in done:
                continue
            t0 = time.time()
            wc_g, _, _ = adversary(win, sol["assign"], sol["order"], G,
                                   enum_cap=0)
            tg = time.time() - t0
            pred = nc * tg / max(1, K * max(G, 1))
            if 0 < nc <= 20000 and pred <= 40.0:
                t0 = time.time()
                wc_e, _, ex = adversary(win, sol["assign"], sol["order"], G,
                                        enum_cap=20000)
                te = time.time() - t0
            else:
                wc_e, ex, te = np.nan, False, np.nan
            rows.append(dict(w=i, plan=name, n_ops=len(win.ops), K=K,
                             Gamma=G, n_comb=nc, wc_greedy=wc_g,
                             wc_exact=wc_e, exact_ok=bool(ex),
                             t_greedy=tg, t_exact=te,
                             agree_eol=agree_eol, agree_all=agree_all))
        pd.DataFrame(rows).to_csv(f"{R}/adv_gap.csv", index=False)
        if (i + 1) % 20 == 0:
            log(f"adv_gap: {i+1}/{len(snaps)}")


# ------------------------------------------------------------------ S10
@stage("bench_saa")
def s10():
    """SAA with more Monte Carlo scenarios (12, 24) under the same audited
    protocol and time limit, on the medium and heavy congestion terciles."""
    uq = get_uq("cell")
    snaps = load_windows()
    Ks = np.array([len(s["win"].uncertain_units()) for s in snaps])
    cut = np.quantile(Ks, 1 / 3)
    idx = [i for i, k in enumerate(Ks) if k > cut]
    done_w = set()
    old = []
    if os.path.exists(f"{R}/bench_saa.csv"):
        df0 = pd.read_csv(f"{R}/bench_saa.csv")
        cnt = df0.groupby("w").method.count()
        done_w = set(cnt[cnt >= 2].index)
        old = [df0[df0.w.isin(done_w)]]
    for j, i in enumerate(idx):
        if i in done_w:
            continue
        d = bench([snaps[i]], uq, tl=1.2, methods=("SAA12", "SAA24"),
                  tag="saa")
        d["w"] = i
        old.append(d)
        pd.concat(old).to_csv(f"{R}/bench_saa.csv", index=False)
        if (j + 1) % 20 == 0:
            log(f"bench_saa: {j+1}/{len(idx)}")


# ------------------------------------------------------------------ S11
@stage("adv_gap_scale")
def s11():
    """Exact vs greedy adversary on the large windows of the scaling stress
    test (K up to ~25), where the paper's audit fell back to greedy."""
    from math import comb
    import glob
    from cords.sched_core import ccg_solve, adversary
    rows, done = resume(f"{R}/adv_gap_scale.csv", ("wcap", "idx"))
    for f in sorted(glob.glob(f"{R}/scale_w*.pkl.gz")):
        wcap = int(f.split("scale_w")[1].split(".")[0])
        snaps = pickle.load(gzip.open(f, "rb"))
        for idx, snap in enumerate(snaps):
            if (wcap, idx) in done:
                continue
            win = snap["win"]
            K = len(win.uncertain_units())
            G = gamma_budget(K, 0.1, 0.1) if K else 0
            nc = comb(K, G) if K else 0
            sol, _ = ccg_solve(win, G, time_limit=3.0 * (1 + len(win.ops) / 18.0),
                               max_add=2)
            if sol is None:
                continue
            t0 = time.time()
            wc_g, _, _ = adversary(win, sol["assign"], sol["order"], G,
                                   enum_cap=0)
            tg = time.time() - t0
            pred = nc * tg / max(1, K * max(G, 1))
            if 0 < nc <= 80000 and pred <= 110.0:
                t0 = time.time()
                wc_e, _, ex = adversary(win, sol["assign"], sol["order"], G,
                                        enum_cap=80000)
                te = time.time() - t0
            else:
                wc_e, ex, te = np.nan, False, np.nan
            rows.append(dict(wcap=wcap, idx=idx, n_ops=len(win.ops), K=K,
                             Gamma=G, n_comb=nc, wc_greedy=wc_g, wc_exact=wc_e,
                             exact_ok=bool(ex), t_greedy=tg, t_exact=te,
                             pred_s=pred))
            pd.DataFrame(rows).to_csv(f"{R}/adv_gap_scale.csv", index=False)
            log(f"adv_gap_scale: wcap {wcap} idx {idx} K={K} nc={nc} exact={ex}")


def main(which="all"):
    ensure_dirs()
    todo = dict(s1=s1, s2=s2, s3=s3, s3b=s3b, s3c=s3c, s4=s4, s5=s5, s6=s6,
                s7=s7, s8=s8, s9=s9, s10=s10, s11=s11)
    order = ["s2", "s3", "s1", "s4", "s3b", "s3c", "s5", "s6",
             "s7", "s8", "s9", "s10", "s11"]
    if which == "all":
        for k in order:
            todo[k]()
    else:
        todo[which]()
    log("ALL STAGES COMPLETE")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "all")
