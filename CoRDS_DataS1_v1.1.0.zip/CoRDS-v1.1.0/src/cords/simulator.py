"""
simulator.py
Event-driven rolling-horizon simulation of a 3-stage battery pack line:
  S1 formation-verification (parallel cycler channels)  -- REAL durations
  S2 module assembly (parallel lines)                   -- nominal +/- small noise
  S3 EOL capacity test (parallel testers)               -- REAL durations
True S1/S3 durations are measured charge / discharge cycle durations of
held-out NASA PCoE cells; features/predictions come from models fitted on
disjoint training/calibration cells.
"""
import time
import heapq
import numpy as np
from cords.paths import DATA_PROC_DIR
import pandas as pd
from cords.ml_uq import CQRModel, OnlineUpper, gamma_budget, FEATURES, temp_group, make_splits
from cords.sched_core import Window, ccg_solve, solve_master, polish

MIN = 60.0  # seconds per minute


# ---------------------------------------------------------------------------
def fit_uq(split="cell", alpha_list=(0.05, 0.1, 0.2), seed=12345):
    """Fit CQR models for both targets; return bundle with test pools."""
    bundle = dict(alpha_list=alpha_list, split=split)
    for tgt, f in [("charge", "ops_charge.csv"), ("discharge", "ops_discharge.csv")]:
        ops = pd.read_csv(DATA_PROC_DIR / f).dropna(
            subset=FEATURES + ["y_duration_s"]).reset_index(drop=True)
        tr, ca, te = make_splits(ops, split, seed)
        X = ops[FEATURES].values.astype(float)
        y = ops.y_duration_s.values.astype(float)
        g = ops.ambient_T.map(temp_group).values
        models = {}
        for a in alpha_list:
            models[a] = CQRModel(alpha=a, mondrian=True).fit(X[tr], y[tr], X[ca], y[ca], g[ca])
        resid = y[ca] - models[0.1].median(X[ca])          # SAA residual pool
        pool = ops[te].reset_index(drop=True)
        bundle[tgt] = dict(models=models, resid=resid, pool=pool,
                           glob_med=float(np.median(y[tr | ca])),
                           glob_q={a: float(np.quantile(y[tr | ca], 1 - a)) for a in alpha_list},
                           X_te=X[te], g_te=g[te],
                           scale=float(np.median(np.abs(y[ca] - models[0.1].q_hi_.predict(X[ca])))))
    return bundle


# ---------------------------------------------------------------------------
DEF_CFG = dict(n_jobs=24, n_mach=(4, 2, 1), mean_ia=50.0, due_base=1.5,
               s2_nom=45, mtbf=2880.0, mttr_mean=45.0, wcap=16,
               alpha=0.1, beta=0.1, tl=1.2, max_add=2, saa_n=6, horizon_pad=4000,
               wcap_s1=8,
               su_scale=1.0, replan="event", freeze=0.0, lam=(1, 1))

SU_BASE = [[0, 60, 90], [60, 0, 60], [90, 60, 0]]   # cold / room / hot
REC_ID = {"cold(4C)": 0, "room(22-24C)": 1, "hot(43-44C)": 2}


def setup_matrix(cfg):
    s = cfg.get("su_scale", 1.0)
    return [[int(round(v * s)) for v in row] for row in SU_BASE]


def gen_instance(seed, uq, cfg=None, pool_filter=None):
    cfg = {**DEF_CFG, **(cfg or {})}
    rng = np.random.default_rng(seed)
    ch, dc = uq["charge"], uq["discharge"]
    pc = ch["pool"] if pool_filter is None else ch["pool"][pool_filter(ch["pool"])].reset_index(drop=True)
    pd_ = dc["pool"] if pool_filter is None else dc["pool"][pool_filter(dc["pool"])].reset_index(drop=True)
    jobs = []
    t = 0.0
    for j in range(cfg["n_jobs"]):
        t += rng.exponential(cfg["mean_ia"])
        rc = pc.iloc[rng.integers(len(pc))]
        same_b = pd_[pd_.battery == rc.battery]
        rd = (same_b.iloc[rng.integers(len(same_b))] if len(same_b)
              else pd_.iloc[rng.integers(len(pd_))])
        w = int(rng.choice([1, 2, 5], p=[0.5, 0.3, 0.2]))
        true1 = max(5, round(rc.y_duration_s / MIN))
        true3 = max(3, round(rd.y_duration_s / MIN))
        nz = int(cfg.get("s2_noise", 6))
        true2 = int(cfg["s2_nom"] + rng.integers(-nz, nz + 1))
        x1 = rc[list(FEATURES)].values.astype(float)
        x3 = rd[list(FEATURES)].values.astype(float)
        g1, g3 = temp_group(rc.ambient_T), temp_group(rd.ambient_T)
        pred = {}
        for a in uq["alpha_list"]:
            m1, m3 = ch["models"][a], dc["models"][a]
            pred[a] = dict(
                up1=float(m1.upper(x1.reshape(1, -1), np.array([g1]))[0]) / MIN,
                up3=float(m3.upper(x3.reshape(1, -1), np.array([g3]))[0]) / MIN,
                raw1=float(m1.q_hi_.predict(x1.reshape(1, -1))[0]) / MIN,
                raw3=float(m3.q_hi_.predict(x3.reshape(1, -1))[0]) / MIN)
        p1 = float(ch["models"][0.1].median(x1.reshape(1, -1))[0]) / MIN
        p3 = float(dc["models"][0.1].median(x3.reshape(1, -1))[0]) / MIN
        due = t + cfg["due_base"] * rng.uniform(0.8, 1.3) * (p1 + cfg["s2_nom"] + p3)
        jobs.append(dict(j=j, arr=t, due=due, w=w, rec=REC_ID[g1],
                         true=(true1, true2, true3), pnom=(p1, cfg["s2_nom"], p3),
                         pred=pred, x=(x1, x3), g=(g1, g3),
                         ysec=(rc.y_duration_s, rd.y_duration_s)))
    # breakdown calendar
    machines = []
    for k, nm in enumerate(cfg["n_mach"]):
        for i in range(nm):
            machines.append((k, f"M{k}_{i}"))
    horizon = t + cfg["horizon_pad"]
    breakdowns = {mid: [] for _, mid in machines}
    if cfg["mtbf"] and np.isfinite(cfg["mtbf"]):
        for _, mid in machines:
            ft = rng.exponential(cfg["mtbf"])
            while ft < horizon:
                rep = float(np.clip(rng.lognormal(np.log(cfg["mttr_mean"]) - 0.125, 0.5), 10, 240))
                breakdowns[mid].append((ft, ft + rep))
                ft = ft + rep + rng.exponential(cfg["mtbf"])
    return dict(jobs=jobs, machines=machines, breakdowns=breakdowns, cfg=cfg, seed=seed)


# ---------------------------------------------------------------------------
RULES = ("FIFO", "SPT", "EDD", "ATC", "ATCS")


class Sim:
    def __init__(self, inst, policy, uq, overrides=None):
        self.inst = inst
        self.policy = policy
        self.uq = uq
        self.cfg = {**inst["cfg"], **(overrides or {})}
        self.rng = np.random.default_rng(inst["seed"] + 777)
        # correlated process shocks (e.g. an HVAC failure inflating every
        # formation duration while active); identical across policies (CRN)
        self.shocks = []
        rate = float(self.cfg.get("shock_rate_h", 0.0) or 0.0)
        if rate > 0:
            srng = np.random.default_rng(inst["seed"] + 4242)
            T = max(j["arr"] for j in inst["jobs"]) + self.cfg.get("horizon_pad", 4000)
            t = 0.0
            while True:
                t += srng.exponential(60.0 / rate)
                if t > T:
                    break
                d = float(np.clip(srng.lognormal(
                    np.log(self.cfg.get("shock_dur", 90.0)) - 0.125, 0.5), 15, 480))
                self.shocks.append((t, t + d))

    # -------------------- policy configuration ------------------------
    def _op_durations(self, job, stage):
        """(p_nom, p_up, uncertain) in minutes for the planner model."""
        a = self.cfg["alpha"]
        p = self.policy
        pn = job["pnom"][stage]
        if stage == 1:
            return self.cfg["s2_nom"], self.cfg["s2_nom"], False
        key_up = "up1" if stage == 0 else "up3"
        key_raw = "raw1" if stage == 0 else "raw3"
        tgt = "charge" if stage == 0 else "discharge"
        if p == "ORACLE":
            return job["true"][stage], job["true"][stage], False
        if p == "DET":
            return pn, pn, False
        if p == "P90":
            u = job["pred"][a][key_up]
            return max(pn, u), max(pn, u), False
        if p == "FIXG":
            return pn, pn * 1.15, True
        if p == "CORDS_noconf":
            return pn, max(pn, job["pred"][a][key_raw]), True
        if p == "CORDS_noml":
            gm = self.uq[tgt]["glob_med"] / MIN
            gq = self.uq[tgt]["glob_q"][a] / MIN
            return gm, max(gm, gq), True
        if p == "CORDS_online":
            u = job["pred"][a][key_raw] + self.online_c[tgt] / MIN
            return pn, max(pn, u), True
        # CORDS, CORDS_noccg, SAA (SAA ignores p_up)
        u = job["pred"][a][key_up]
        return pn, max(pn, u), True

    # -------------------- window construction -------------------------
    def _build_window(self, t):
        cfg = self.cfg
        mach_rec = {}
        for (k, mid) in self.inst["machines"]:
            if k != 0:
                continue
            m = self.mach[mid]
            mach_rec[mid] = m["su_target"] if m["state"] == "setup" else m["rec"]
        win = Window(stages=[0, 1, 2],
                     machines_per_stage={k: [mid for kk, mid in self.inst["machines"] if kk == k]
                                         for k in range(3)},
                     setup=setup_matrix(cfg), mach_rec=mach_rec)
        cand = [j for j in self.jobs_state
                if j["arrived"] and j["next_stage"] < 3]
        cand.sort(key=lambda j: j["due"])
        must = {int(oid[1:].split("S")[0]) for oid in getattr(self, "_frozen_now", {})}
        active = [j for j in cand if j["job"]["j"] in must]
        for j in cand:
            if len(active) >= cfg["wcap"]:
                break
            if j["job"]["j"] not in must:
                active.append(j)
        # guarantee formation-stage backlog is represented in the window
        s1_in = sum(1 for j in active if j["next_stage"] == 0 and j["running_on"] is None)
        if s1_in < cfg["wcap_s1"]:
            for j in cand:
                if s1_in >= cfg["wcap_s1"]:
                    break
                if (j not in active and j["next_stage"] == 0
                        and j["running_on"] is None):
                    active.append(j)
                    s1_in += 1
        planned_ops = set()
        for js in active:
            job = js["job"]
            for k in range(js["next_stage"], 3):
                if k == js["next_stage"] and js["running_on"] is not None:
                    continue  # current op running -> handled as run_op
                pn, pu, unc = self._op_durations(job, k)
                oid = f"J{job['j']}S{k}"
                win.add_op(oid, job["j"], k, pn, pu, unc,
                           rec=(job["rec"] if k == 0 else None))
                planned_ops.add(oid)
            win.jobs[job["j"]] = dict(due=round(js["due"] - t), w=job["w"])
        # machine availability & running ops
        for (k, mid) in self.inst["machines"]:
            m = self.mach[mid]
            base = 0
            if m["down_until"] is not None and m["down_until"] > t:
                base = round(m["down_until"] - t)
            if m["state"] == "setup":
                base = max(base, round(m["su_end"] - t))
            win.mach_avail[mid] = base
            if m["op"] is not None:
                js = self.jobs_state[m["op"]["j"]]
                job = js["job"]
                stage = m["op"]["stage"]
                pn, pu, unc = self._op_durations(job, stage)
                done = m["op"]["done_work"] + (max(0.0, t - m["op"]["last_start"]) if m["state"] == "busy" else 0.0)
                rem_n = max(1, round(pn - done))
                rem_u = max(rem_n, round(pu - done))
                if job["j"] in win.jobs:
                    win.run_ops.append(dict(id=f"J{job['j']}S{stage}R", job=job["j"],
                                            stage=stage, machine=mid,
                                            rem_nom=rem_n, rem_up=rem_u, uncertain=unc))
                else:
                    win.mach_avail[mid] = base + rem_n
        return win, planned_ops

    def _saa_scenarios(self, win):
        n = self.cfg["saa_n"]
        scens = [win.scenario(set())]
        rng = self.rng
        for _ in range(n - 1):
            sc = win.scenario(set())
            for o in win.ops:
                if o["uncertain"]:
                    tgt = "charge" if o["stage"] == 0 else "discharge"
                    r = rng.choice(self.uq[tgt]["resid"]) / MIN
                    sc["d"][o["id"]] = int(max(1, round(o["d_nom"] + r)))
            scens.append(sc)
        return scens

    def _replan(self, t):
        frozen = {}
        F = self.cfg.get("freeze", 0.0)
        if F > 0 and self.plan_start_abs:
            for m, seq in self.plan.items():
                ix = 0
                for oid in seq:
                    jn = int(oid[1:].split("S")[0])
                    kk = int(oid.split("S")[1])
                    js = self.jobs_state[jn]
                    if js["done_t"] is not None or js["next_stage"] > kk or js["running_on"] is not None:
                        continue
                    if self.plan_start_abs.get(oid, 1e18) < t + F:
                        frozen[oid] = (m, ix)
                        ix += 1
        self._frozen_now = frozen
        win, planned = self._build_window(t)
        win.frozen = {o: v for o, v in frozen.items()
                      if any(o == op["id"] for op in win.ops)}
        if self.snapshots is not None and win.ops:
            aux = {}
            for o in win.ops:
                job = self.jobs_state[o["job"]]["job"]
                k = o["stage"]
                aux[o["id"]] = dict(
                    pn=job["pnom"][k], true=float(job["true"][k]), stage=k,
                    up={a: (job["pred"][a]["up1"] if k == 0 else job["pred"][a]["up3"])
                        for a in self.uq["alpha_list"]} if k in (0, 2) else None,
                    raw={a: (job["pred"][a]["raw1"] if k == 0 else job["pred"][a]["raw3"])
                         for a in self.uq["alpha_list"]} if k in (0, 2) else None)
            self.snapshots.append(dict(t=t, win=win, aux=aux,
                                       seed=self.inst["seed"]))
        if not win.ops:
            self.plan = {m: [] for _, m in self.inst["machines"]}
            self.plan_start_abs = {}
            self.planned_ops = set()
            return
        cfg = self.cfg
        p = self.policy
        t0 = None
        if p in ("DET", "ORACLE", "P90", "SNAP"):
            sol = solve_master(win, [win.scenario(set())], time_limit=cfg["tl"], mode="single")
            info = dict(master_time=sol["walltime"] if sol else 0, adv_time=0, iters=1, n_scen=1)
        elif p == "SAA":
            sol = solve_master(win, self._saa_scenarios(win), time_limit=cfg["tl"] * 1.5, mode="saa")
            info = dict(master_time=sol["walltime"] if sol else 0, adv_time=0, iters=1, n_scen=cfg["saa_n"])
        else:  # robust family
            K = len(win.uncertain_units())
            Gam = gamma_budget(K, cfg["alpha"], cfg["beta"])
            max_add = 0 if p == "CORDS_noccg" else cfg["max_add"]
            sol, info = ccg_solve(win, Gam, time_limit=cfg["tl"], max_add=max_add,
                                  lam=tuple(cfg.get("lam", (1, 1))))
            if sol is not None and cfg.get("polish_s", 1.2) > 0:
                t_p = time.time()
                sol = polish(win, sol, Gam, lam=tuple(cfg.get("lam", (1, 1))),
                             budget_s=cfg.get("polish_s", 1.2))
                self.diag["master_time"] += time.time() - t_p
        if sol is None:   # fallback: keep previous plan
            self.diag["fails"] += 1
            return
        self.diag["master_time"] += info.get("master_time", 0)
        self.diag["adv_time"] += info.get("adv_time", 0)
        self.diag["scen"] .append(info.get("n_scen", 1))
        # nervousness vs previous plan
        newstart = {oid: t + s for oid, s in sol["plan_start"].items()}
        common = [o for o in newstart if o in self.plan_start_abs]
        if common and self.n_replans > 0:
            self.diag["nerv"].append(float(np.mean([abs(newstart[o] - self.plan_start_abs[o]) for o in common])))
        self.plan_start_abs = newstart
        self.plan = sol["order"]
        self.planned_ops = planned
        self.n_replans += 1

    # -------------------- event loop ----------------------------------
    def run(self):
        inst = self.inst
        self.jobs_state = [dict(job=j, arrived=False, next_stage=0, running_on=None,
                                stage_done_t=[None, None, None], done_t=None, due=j["due"])
                           for j in inst["jobs"]]
        self.mach = {mid: dict(stage=k, state="idle", op=None, down_until=-1.0,
                               rec=(1 if k == 0 else None), su_target=None,
                               su_end=-1.0, su_ver=0)
                     for k, mid in inst["machines"]}
        self.SU = setup_matrix(self.cfg)
        self.plan = {mid: [] for _, mid in inst["machines"]}
        self.plan_start_abs = {}
        self.planned_ops = set()
        self.n_replans = 0
        self.online_c = dict(charge=self.uq["charge"]["models"][self.cfg["alpha"]].c_up_["ALL"],
                             discharge=self.uq["discharge"]["models"][self.cfg["alpha"]].c_up_["ALL"])
        self.diag = dict(master_time=0.0, adv_time=0.0, nerv=[], scen=[], fails=0,
                         setup_min=0.0)
        self.snapshots = [] if getattr(self, "snapshot", False) else None

        EV = []  # (time, prio, kind, payload)
        self.periodic = self.cfg["replan"] != "event"
        if self.periodic:
            P = float(self.cfg["replan"])
            tmax = max(j["arr"] for j in inst["jobs"]) + self.cfg["horizon_pad"]
            tt = 0.0
            while tt < tmax:
                heapq.heappush(EV, (tt, 0, "timer", None))
                tt += P
        for js in self.jobs_state:
            heapq.heappush(EV, (js["job"]["arr"], 0, "arr", js["job"]["j"]))
        for mid, lst in inst["breakdowns"].items():
            for (ft, rt) in lst:
                heapq.heappush(EV, (ft, 1, "fail", mid))
                heapq.heappush(EV, (rt, 2, "repair", mid))
        t = 0.0
        seqc = 0
        while EV:
            if all(js["done_t"] is not None for js in self.jobs_state):
                break
            t, _, kind, pay = heapq.heappop(EV)
            if kind == "timer":
                if self.policy not in RULES:
                    self._replan(t)
            elif kind == "arr":
                self.jobs_state[pay]["arrived"] = True
                if self.policy not in RULES and not self.periodic:
                    self._replan(t)
            elif kind == "fail":
                m = self.mach[pay]
                m["down_until"] = None  # set at repair event; mark down
                m["state_before"] = m["state"]
                if m["state"] == "busy":
                    m["op"]["done_work"] += t - m["op"]["last_start"]
                    # cancel its completion event by versioning
                    m["op"]["ver"] += 1
                if m["state"] == "setup":
                    m["su_ver"] += 1        # cancel setup, recipe unchanged
                    m["su_target"] = None
                m["state"] = "down"
                if self.policy not in RULES:
                    # need down_until for planning: find it from calendar
                    for (ft, rt) in inst["breakdowns"][pay]:
                        if abs(ft - t) < 1e-6:
                            m["down_until"] = rt
                            break
                    self._replan(t)
                else:
                    for (ft, rt) in inst["breakdowns"][pay]:
                        if abs(ft - t) < 1e-6:
                            m["down_until"] = rt
                            break
            elif kind == "repair":
                m = self.mach[pay]
                m["state"] = "busy" if m["op"] is not None else "idle"
                m["down_until"] = -1.0
                if m["op"] is not None:
                    m["op"]["last_start"] = t
                    rem = m["op"]["true"] - m["op"]["done_work"]
                    m["op"]["ver"] += 1
                    heapq.heappush(EV, (t + max(0.01, rem), 3, "done", (pay, m["op"]["ver"])))
                if self.policy not in RULES:
                    self._replan(t)
            elif kind == "sudone":
                mid, ver, target = pay
                m = self.mach[mid]
                if m["state"] == "setup" and m["su_ver"] == ver:
                    m["rec"] = target
                    m["su_target"] = None
                    m["state"] = "idle"
            elif kind == "done":
                mid, ver = pay
                m = self.mach[mid]
                if m["op"] is None or m["op"]["ver"] != ver or m["state"] != "busy":
                    continue  # stale event
                op = m["op"]
                m["op"] = None
                m["state"] = "idle"
                js = self.jobs_state[op["j"]]
                js["running_on"] = None
                js["stage_done_t"][op["stage"]] = t
                js["next_stage"] = op["stage"] + 1
                if js["next_stage"] == 3:
                    js["done_t"] = t
                # online calibration update at completion of real ops
                if self.policy == "CORDS_online" and op["stage"] in (0, 2):
                    tgt = "charge" if op["stage"] == 0 else "discharge"
                    job = js["job"]
                    x = job["x"][0 if op["stage"] == 0 else 1]
                    y = job["ysec"][0 if op["stage"] == 0 else 1]
                    mdl = self.uq[tgt]["models"][self.cfg["alpha"]]
                    u = float(mdl.q_hi_.predict(x.reshape(1, -1))[0]) + self.online_c[tgt]
                    err = 1.0 if y > u else 0.0
                    self.online_c[tgt] += 0.05 * (err - self.cfg["alpha"]) * 3 * self.uq[tgt]["scale"]
                if (self.policy not in RULES and not self.periodic
                        and self._has_unplanned(t)):
                    self._replan(t)
            # dispatch sweep
            seqc = self._sweep(t, EV, seqc)
        return self._metrics()

    def _has_unplanned(self, t):
        for js in self.jobs_state:
            if js["arrived"] and js["next_stage"] < 3 and js["running_on"] is None:
                oid = f"J{js['job']['j']}S{js['next_stage']}"
                if oid not in self.planned_ops:
                    return True
        return False

    def _ready(self, js, k):
        return (js["arrived"] and js["next_stage"] == k and js["running_on"] is None)

    def _start(self, mid, js, k, t, EV):
        job = js["job"]
        m = self.mach[mid]
        su = self.SU[m["rec"]][job["rec"]] if (k == 0 and m["rec"] is not None) else 0
        self.diag["setup_min"] += su
        true_k = float(job["true"][k])
        shocked = False
        if self.shocks and k in tuple(self.cfg.get("shock_stages", (0,))):
            for a, b in self.shocks:
                if a <= t < b:
                    true_k *= float(self.cfg.get("shock_factor", 1.4))
                    shocked = True
                    break
        pn_, pu_, unc_ = self._op_durations(job, k)
        if unc_:
            self.diag["cov_n"] = self.diag.get("cov_n", 0) + 1
            self.diag["cov_x"] = self.diag.get("cov_x", 0) + int(true_k > pu_)
            if shocked:
                self.diag["shk_n"] = self.diag.get("shk_n", 0) + 1
                self.diag["shk_x"] = self.diag.get("shk_x", 0) + int(true_k > pu_)
        op = dict(j=job["j"], stage=k, true=true_k + su,
                  done_work=0.0, last_start=t, ver=0)
        m["op"] = op
        m["state"] = "busy"
        if k == 0:
            m["rec"] = job["rec"]
        js["running_on"] = mid
        heapq.heappush(EV, (t + op["true"], 3, "done", (mid, 0)))

    def _sweep(self, t, EV, seqc):
        moved = True
        while moved:
            moved = False
            for (k, mid) in self.inst["machines"]:
                m = self.mach[mid]
                if m["state"] != "idle":
                    continue
                if self.policy in RULES:
                    ready = [js for js in self.jobs_state if self._ready(js, k)]
                    if not ready:
                        continue
                    js = self._pick_rule(ready, k, t, mid)
                else:
                    seq = self.plan.get(mid, [])
                    front = None
                    while seq:
                        oid = seq[0]
                        jn = int(oid[1:].split("S")[0])
                        kk = int(oid.split("S")[1])
                        cand = self.jobs_state[jn]
                        if cand["next_stage"] > kk or cand["done_t"] is not None:
                            seq.pop(0)   # already done / superseded
                            continue
                        front = (cand, kk)
                        break
                    if front is None:
                        continue
                    cand, kk = front
                    if kk != k:
                        continue
                    # anticipatory thermal changeover on formation chambers
                    if k == 0 and m["rec"] != cand["job"]["rec"]:
                        su = self.SU[m["rec"]][cand["job"]["rec"]]
                        self.diag["setup_min"] += su
                        m["state"] = "setup"
                        m["su_target"] = cand["job"]["rec"]
                        m["su_ver"] += 1
                        m["su_end"] = t + su
                        heapq.heappush(EV, (t + su, 3, "sudone",
                                            (mid, m["su_ver"], cand["job"]["rec"])))
                        moved = True
                        continue
                    if not self._ready(cand, kk):
                        continue
                    js = cand
                    seq.pop(0)
                self._start(mid, js, k, t, EV)
                moved = True
                seqc += 1
        return seqc

    def _pick_rule(self, ready, k, t, mid):
        p = self.policy
        if p == "FIFO":
            return min(ready, key=lambda js: js["job"]["arr"])
        if p == "SPT":
            return min(ready, key=lambda js: js["job"]["pnom"][k])
        if p == "EDD":
            return min(ready, key=lambda js: js["due"])
        # ATC / ATCS (Lee & Pinedo style)
        m = self.mach[mid]
        pbar = float(np.mean([js["job"]["pnom"][k] for js in ready]))
        sus = [self.SU[m["rec"]][js["job"]["rec"]] if (k == 0 and m["rec"] is not None) else 0
               for js in ready]
        sbar = max(1.0, float(np.mean(sus)))
        def idx(i_js):
            i, js = i_js
            rem = sum(js["job"]["pnom"][kk] for kk in range(js["next_stage"], 3))
            slack = max(0.0, js["due"] - t - rem)
            v = (js["job"]["w"] / max(1e-6, js["job"]["pnom"][k])) * np.exp(-slack / (2 * pbar))
            if p == "ATCS":
                v *= np.exp(-sus[i] / (0.5 * sbar))
            return -v
        return min(enumerate(ready), key=idx)[1]
    def _metrics(self):
        rows = []
        for js in self.jobs_state:
            j = js["job"]
            tard = max(0.0, js["done_t"] - j["due"])
            rows.append(dict(j=j["j"], w=j["w"], arr=j["arr"], due=j["due"],
                             done=js["done_t"], tard=tard, flow=js["done_t"] - j["arr"]))
        df = pd.DataFrame(rows)
        w5 = df[df.w == 5]
        return dict(policy=self.policy, seed=self.inst["seed"],
                    twt=float((df.w * df.tard).sum()),
                    on_time=float((df.tard <= 1e-9).mean()),
                    ot_w5=float((w5.tard <= 1e-9).mean()) if len(w5) else np.nan,
                    tard_w5=float(w5.tard.mean()) if len(w5) else np.nan,
                    setup_min=float(self.diag.get("setup_min", 0.0)),
                    p95_tard=float(np.percentile(df.tard, 95)),
                    mean_tard=float(df.tard.mean()),
                    makespan=float(df.done.max()),
                    mean_flow=float(df.flow.mean()),
                    nerv=float(np.mean(self.diag["nerv"])) if self.diag["nerv"] else 0.0,
                    n_replans=self.n_replans,
                    solver_s=self.diag["master_time"] + self.diag["adv_time"],
                    n_scen_avg=float(np.mean(self.diag["scen"])) if self.diag["scen"] else 1.0,
                    fails=self.diag["fails"],
                    coverage=(1 - self.diag.get("cov_x", 0) / self.diag["cov_n"])
                    if self.diag.get("cov_n", 0) else np.nan,
                    shock_ops=self.diag.get("shk_n", 0),
                    shock_coverage=(1 - self.diag.get("shk_x", 0) / self.diag["shk_n"])
                    if self.diag.get("shk_n", 0) else np.nan,
                    n_shocks=len(self.shocks))


def run_policy(inst, policy, uq, overrides=None):
    return Sim(inst, policy, uq, overrides).run()
