# Raw NASA data (not redistributed)

Download the NASA Ames "Battery Data Set" (Saha & Goebel, 2007) from the
NASA Prognostics Center of Excellence data repository and place the
extracted `.mat` files under this directory (any layout containing the
`B00xx.mat` files works; `scripts/data_prep.py --data-dir` may also point
anywhere else).

The processed per-operation tables extracted from it are already shipped
in `data/processed/`, so downloading the raw data is only needed to
re-run the extraction step itself.
