# Reproducing the paper

## Levels of reproduction

1. **Tables/figures from shipped logs (seconds).**
   `python scripts/make_figs_tables.py` regenerates every display item
   and `numbers.tex` macro into `outputs_paper/` from `results/*.csv`.
2. **Smoke test (about two minutes).**
   `python scripts/run_smoke_test.py` checks the budget rule, solves and
   independently audits one real decision window using the shipped CQR
   models, and regenerates one table.
3. **Full experiment suite (several CPU-hours).**
   `python scripts/run_experiments.py all` re-runs stages s1-s6 below.
   The driver is resumable: completed units are skipped, so it is safe
   to interrupt and restart.
4. **From raw data.** Download the NASA set (see `data/raw/README.md`),
   then `python scripts/data_prep.py`, then level 3.

## Stages

| Stage | Produces | Approx. time |
| --- | --- | --- |
| s1 | `uq_cell.pkl`, `uq_shift.pkl`, `rq1_*.csv` | ~10 min |
| s2 | `windows.pkl.gz` (176 frozen windows) | ~15 min |
| s3 | `bench_main.csv` (9 methods x 176 windows, common audit) | ~2 h |
| s3b/s3c | `bench_alpha.csv`, `bench_lambda.csv` | ~1 h |
| s4 | `main_loop.csv`, `drift_loop.csv` | ~1.5 h |
| s5 | `sens_loop.csv` | ~1 h |
| s6 | `scale.csv` | ~15 min |

Seeds are fixed in the driver; all closed-loop comparisons use common
random numbers. Statistical procedures are described in the paper's
"Quantification and statistical analysis" section.

## Paper display items -> code

| Item | Generator (in `src/cords/make_figs_tables.py`) | Inputs |
| --- | --- | --- |
| Fig. 2, Table 1, Table S1 | `fig_data`, `rq1` | `data/processed/ops_*.csv`, `rq1_*.csv` |
| Fig. 3, Table 2 | `bench` | `bench_main.csv` |
| Fig. 4, Table S2 | `alpha_lambda` | `bench_lambda.csv`, `bench_alpha.csv` |
| Table 3, Table 4 | `main_loop`, `drift` | `main_loop.csv`, `drift_loop.csv` |
| Tables S3, S4 | `sens`, `scale` | `sens_loop.csv`, `scale.csv` |
