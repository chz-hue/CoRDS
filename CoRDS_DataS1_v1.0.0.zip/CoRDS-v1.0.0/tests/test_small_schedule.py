from cords.ml_uq import gamma_budget
from cords.sched_core import Window, adversary, ccg_solve, evaluate_fixed


def toy_window():
    win = Window(stages=[0, 1, 2],
                 machines_per_stage={0: [0, 1], 1: [2], 2: [3]},
                 setup=[[0, 60], [60, 0]], mach_rec={0: 0, 1: 1})
    for m in (0, 1, 2, 3):
        win.mach_avail[m] = 0
    for j, (due, w, rec) in enumerate(
            [(240, 1, 0), (200, 2, 1), (300, 5, 0)], start=1):
        win.jobs[j] = dict(due=due, w=w)
        win.job_ready_base[j] = 0
        win.add_op(f"J{j}S0", j, 0, d_nom=35, d_up=70, uncertain=True,
                   rec=rec)
        win.add_op(f"J{j}S1", j, 1, d_nom=10, d_up=10, uncertain=False)
        win.add_op(f"J{j}S2", j, 2, d_nom=45, d_up=95, uncertain=True)
    return win


def test_certificate_is_audited_and_consistent():
    win = toy_window()
    K = len(win.uncertain_units())
    G = gamma_budget(K, 0.1, 0.1)
    assert 0 < G <= K
    sol, info = ccg_solve(win, G, time_limit=1.5)
    wc_aud, _, _ = adversary(win, sol["assign"], sol["order"], G)
    # the returned certificate must equal an independent audit of the plan
    assert abs(wc_aud - sol["wc_true"]) <= 1e-6
    # nominal cost of the same plan can never exceed the certificate
    nom, _, _ = evaluate_fixed(win, sol["assign"], sol["order"],
                               win.scenario(set()))
    assert nom <= sol["wc_true"] + 1e-6
