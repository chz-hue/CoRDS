from scipy.stats import binom

from cords.ml_uq import gamma_budget


def test_tail_bound_and_minimality():
    for K in (1, 5, 12, 24, 60):
        for a in (0.05, 0.1, 0.2):
            for b in (0.05, 0.1):
                g = gamma_budget(K, a, b)
                assert 0 <= g <= K
                assert binom.sf(g, K, a) <= b + 1e-12
                if g > 0:
                    assert binom.sf(g - 1, K, a) > b


def test_monotone_in_K_and_edge():
    assert gamma_budget(0, 0.1, 0.1) == 0
    gs = [gamma_budget(K, 0.1, 0.1) for K in range(1, 40)]
    assert all(y >= x for x, y in zip(gs, gs[1:]))
