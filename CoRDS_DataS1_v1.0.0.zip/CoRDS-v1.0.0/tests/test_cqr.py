import numpy as np

from cords.ml_uq import CQRModel


def test_mondrian_upper_coverage_heteroscedastic():
    rng = np.random.default_rng(0)
    n = 1600
    g = rng.choice(["A", "B"], n)
    x = rng.uniform(0, 1, n)
    scale = np.where(g == "A", 0.1, 1.0)
    y = 2 * x + scale * rng.standard_normal(n)
    X = np.c_[x, (g == "B").astype(float)]
    tr, ca = slice(0, 800), slice(800, 1200)
    te = slice(1200, None)
    m = CQRModel(alpha=0.2)
    m.fit(X[tr], y[tr], X[ca], y[ca], g[ca])
    up = m.upper(X[te], g[te])
    yte, gte, xte = y[te], g[te], x[te]
    cov = float(np.mean(yte <= up))
    assert cov >= 0.8 - 0.05, cov
    for grp in ("A", "B"):
        c = float(np.mean(yte[gte == grp] <= up[gte == grp]))
        assert c >= 0.8 - 0.08, (grp, c)
    # width must adapt to heteroscedasticity: slack over the true mean 2x
    slack = up - 2 * xte
    assert (slack[gte == "B"].mean()
            > slack[gte == "A"].mean() + 0.3), "no Mondrian adaptation"
