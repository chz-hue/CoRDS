#!/usr/bin/env python3
import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / "src"))


def apply_config(path):
    if not path:
        return
    import yaml
    cfg = yaml.safe_load(Path(path).read_text()) or {}
    env = dict(root="CORDS_ROOT", data_raw="CORDS_DATA_RAW",
               data_processed="CORDS_DATA_PROC", results="CORDS_RESULTS",
               paper_out="CORDS_PAPER_OUT")
    for k, v in (cfg.get("paths") or {}).items():
        os.environ[env[k]] = str(Path(v).expanduser().resolve())


def cli():
    ap = argparse.ArgumentParser(
        description="Few-minute end-to-end check on shipped artifacts.")
    ap.add_argument("--config", help="YAML config overriding paths")
    a = ap.parse_args()
    apply_config(a.config)
    import pickle
    import time
    from cords.paths import RESULTS_DIR, ensure_dirs
    ensure_dirs()
    from cords.ml_uq import gamma_budget
    from cords.sched_core import adversary
    from cords.bench import collect_windows

    print("== 1/3 budget rule ==")
    for K in (6, 12, 24):
        print(f"   Gamma(K={K}, alpha=0.1, beta=0.1) =",
              gamma_budget(K, 0.1, 0.1))

    print("== 2/3 one certified window solve (shipped UQ models) ==")
    uq = pickle.load(open(RESULTS_DIR / "uq_cell.pkl", "rb"))
    cfg = dict(n_jobs=8, mean_ia=45.0, wcap=10, wcap_s1=5)
    snaps = collect_windows(uq, seeds=[42], cfg=cfg, cap_per_inst=2)
    snap = max(snaps, key=lambda s: len(s["win"].ops))
    win = snap["win"]
    K = len(win.uncertain_units())
    G = gamma_budget(K, 0.1, 0.1)
    from cords.sched_core import ccg_solve
    t0 = time.time()
    sol, info = ccg_solve(win, G, time_limit=2.0)
    wc_aud, _, exact = adversary(win, sol["assign"], sol["order"], G)
    print(f"   window: {len(win.ops)} ops, K={K}, Gamma={G}; "
          f"solve {time.time()-t0:.1f}s; certificate={sol['wc_true']}, "
          f"independent audit={wc_aud} (exact={exact})")
    assert abs(wc_aud - sol["wc_true"]) <= 1e-6, "audit != certificate"

    print("== 3/3 table regeneration from shipped logs ==")
    os.environ.setdefault("CORDS_PAPER_OUT", "/tmp/cords_smoke_out")
    import importlib
    import cords.paths
    importlib.reload(cords.paths)
    from cords import make_figs_tables as mft
    importlib.reload(mft)
    mft.ensure_dirs() if hasattr(mft, "ensure_dirs") else None
    mft.main()
    out = Path(os.environ["CORDS_PAPER_OUT"]) / "tabs" / "tab_main.tex"
    assert out.exists(), out
    print("   regenerated:", out)
    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    cli()
