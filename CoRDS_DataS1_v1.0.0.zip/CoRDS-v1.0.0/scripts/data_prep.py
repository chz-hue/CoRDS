#!/usr/bin/env python3
import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / "src"))


def apply_config(path):
    if not path:
        return
    import yaml
    cfg = yaml.safe_load(Path(path).read_text()) or {}
    env = dict(root="CORDS_ROOT", data_raw="CORDS_DATA_RAW",
               data_processed="CORDS_DATA_PROC", results="CORDS_RESULTS",
               paper_out="CORDS_PAPER_OUT")
    for k, v in (cfg.get("paths") or {}).items():
        os.environ[env[k]] = str(Path(v).expanduser().resolve())


def cli():
    ap = argparse.ArgumentParser(
        description="Extract per-operation tables from NASA .mat files.")
    ap.add_argument("--data-dir", help="directory with raw NASA data")
    ap.add_argument("--output-dir", help="directory for processed CSVs")
    ap.add_argument("--config", help="YAML config overriding paths")
    a = ap.parse_args()
    apply_config(a.config)
    if a.data_dir:
        os.environ["CORDS_DATA_RAW"] = str(Path(a.data_dir).resolve())
    if a.output_dir:
        os.environ["CORDS_DATA_PROC"] = str(Path(a.output_dir).resolve())
    from cords.paths import ensure_dirs
    ensure_dirs()
    from cords import data_prep
    data_prep.main()


if __name__ == "__main__":
    cli()
