#!/usr/bin/env python3
import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / "src"))


def apply_config(path):
    if not path:
        return
    import yaml
    cfg = yaml.safe_load(Path(path).read_text()) or {}
    env = dict(root="CORDS_ROOT", data_raw="CORDS_DATA_RAW",
               data_processed="CORDS_DATA_PROC", results="CORDS_RESULTS",
               paper_out="CORDS_PAPER_OUT")
    for k, v in (cfg.get("paths") or {}).items():
        os.environ[env[k]] = str(Path(v).expanduser().resolve())


def cli():
    ap = argparse.ArgumentParser(
        description="Regenerate every paper table/figure/number from logs.")
    ap.add_argument("--results-dir", help="directory with result CSVs")
    ap.add_argument("--out-dir", help="output directory (tabs/, figs/)")
    ap.add_argument("--config", help="YAML config overriding paths")
    a = ap.parse_args()
    apply_config(a.config)
    if a.results_dir:
        os.environ["CORDS_RESULTS"] = str(Path(a.results_dir).resolve())
    if a.out_dir:
        os.environ["CORDS_PAPER_OUT"] = str(Path(a.out_dir).resolve())
    from cords import make_figs_tables
    make_figs_tables.main()


if __name__ == "__main__":
    cli()
