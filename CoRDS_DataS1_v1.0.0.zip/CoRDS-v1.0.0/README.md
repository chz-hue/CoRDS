# CoRDS: Conformal-Robust Dynamic Scheduling

Code and experiment logs accompanying the manuscript *"A hybrid machine
learning and robust optimization framework for dynamic production
scheduling in lithium-ion battery pack manufacturing"* (submitted to
iScience). This archive is **Data S1**: it contains the full source, the
extracted per-operation tables, and every experiment log needed to
regenerate each number, table, and figure in the paper.

## Layout

```
CoRDS-v1.0.0/
|-- README.md, LICENSE, CITATION.cff
|-- requirements.txt, environment.yml, pyproject.toml
|-- src/cords/            library (UQ, budget rule, CP-SAT masters,
|                          audited anytime C&CG, simulator, benchmark,
|                          figure/table generation, path handling)
|-- scripts/              command-line entry points
|-- configs/default.yaml  optional path overrides
|-- data/
|   |-- raw/              put NASA .mat files here (not redistributed)
|   `-- processed/        extracted operation tables (shipped)
|-- results/              experiment logs + fitted models (shipped)
|-- tests/                minute-scale unit tests (pytest)
`-- docs/REPRODUCING.md   stage-by-stage reproduction guide
```

## Installation

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

(Equivalently `conda env create -f environment.yml`, or
`pip install -e .` to install the `cords` package.)

## Quick start

```bash
# 1) minute-scale sanity checks
pytest tests/
python scripts/run_smoke_test.py

# 2) regenerate every paper table/figure from the shipped logs (seconds)
python scripts/make_figs_tables.py            # -> outputs_paper/

# 3) full reproduction from scratch (several CPU-hours, resumable)
python scripts/run_experiments.py all

# 4) optional: rebuild the operation tables from raw NASA data
python scripts/data_prep.py --data-dir data/raw --output-dir data/processed
```

All paths are relative to the repository root and can be overridden with
CLI flags, `--config configs/default.yaml`, or `CORDS_*` environment
variables (see `src/cords/paths.py`); no absolute paths are hard-coded.

## Data

Raw NASA battery aging data (Saha & Goebel, 2007) is **not**
redistributed; `data/raw/README.md` explains where to obtain it. The
processed tables derived from it (`data/processed/ops_charge.csv`,
`ops_discharge.csv`, `cycles.csv`) are included, as are all experiment
logs (`results/`, documented in `results/README.md`).

## Naming note

The method is written **CoRDS** in the paper. Machine-readable policy
keys in code and CSVs use the uppercase identifier `CORDS` (alongside
`DET`, `P90`, `SAA`, `ORACLE`, ...); the display-name mapping is
`cords.make_figs_tables.NAME`. Keys are kept uppercase so that the
shipped logs remain byte-identical to the runs behind the paper.

## Scope of the theoretical claims

`cords.ml_uq.gamma_budget` computes the binomial budget of Definition 1;
the probabilistic certificate (Proposition 2 of the paper) holds under
the independence assumptions stated there and discussed in the paper's
"Limitations of the study". The code audits every reported worst case
with an explicit adversary but does not - and cannot - establish the
distributional assumptions themselves.

## License and citation

MIT (see `LICENSE`). Please cite the article; machine-readable metadata
is in `CITATION.cff`.
