"""
sched_core.py
Robust hybrid-flow-shop window scheduling:
  * scenario-based master (CP-SAT): shared machine assignment + priority
    sequence (first stage decisions), per-scenario start times (adjustable
    timing), objective = min worst-case total weighted tardiness (TWT)
    with nominal tie-break.
  * fixed-decision forward evaluator (list schedule under fixed assignment
    and sequence) -- used by the adversary and for diagnostics.
  * budgeted adversary: max TWT over z in {0,1}^K, sum z <= Gamma, where
    d_o(z) = d_nom + z_o * delta_o (exact enumeration when small, otherwise
    greedy + 1-swap local search).
  * column-and-constraint generation (C&CG) loop.

All times are integer minutes, relative to the rescheduling epoch (t=0).
"""
import itertools
import math
import time
import numpy as np
from ortools.sat.python import cp_model


# ---------------------------------------------------------------------------
class Window:
    """Snapshot of the shop at a rescheduling epoch."""

    def __init__(self, stages, machines_per_stage, setup=None, mach_rec=None):
        self.stages = stages                       # e.g. [0,1,2]
        self.machines = machines_per_stage         # {stage: [machine ids]}
        self.ops = []                              # decision ops (unstarted)
        self.jobs = {}                             # job -> dict(due, w)
        self.mach_avail = {}                       # m -> base avail (certain)
        self.run_ops = []                          # running/paused ops:
        #   dict(id, job, stage, machine, rem_nom, rem_up, uncertain)
        self.job_ready_base = {}                   # job -> earliest start of
        #   its first pending op due to already-finished preds (certain part)
        self.setup = setup                         # matrix SU[r1][r2] (stage 0)
        self.mach_rec = mach_rec or {}             # stage-0 machine -> recipe id
        self.frozen = {}                           # op id -> (machine, order idx)

    def su(self, r1, r2):
        if self.setup is None or r1 is None or r2 is None:
            return 0
        return int(self.setup[r1][r2])

    def add_op(self, oid, job, stage, d_nom, d_up, uncertain, rec=None):
        self.ops.append(dict(id=oid, job=job, stage=stage,
                             d_nom=int(max(1, round(d_nom))),
                             d_up=int(max(1, round(d_up))),
                             uncertain=bool(uncertain), rec=rec))

    # ---- uncertainty bookkeeping --------------------------------------
    def uncertain_units(self):
        """units the adversary can inflate: decision ops + running ops"""
        units = []
        for o in self.ops:
            if o["uncertain"] and o["d_up"] > o["d_nom"]:
                units.append(("op", o["id"], o["d_up"] - o["d_nom"]))
        for r in self.run_ops:
            if r["uncertain"] and r["rem_up"] > r["rem_nom"]:
                units.append(("run", r["id"], r["rem_up"] - r["rem_nom"]))
        return units

    def scenario(self, z_set):
        """Build a scenario dict from the set of inflated units, given as
        (kind, id) 2-tuples with kind in {'op','run'}."""
        zs = {(k, i) for (k, i, *_) in z_set}
        d = {o["id"]: (o["d_up"] if ("op", o["id"]) in zs else o["d_nom"])
             for o in self.ops}
        avail = dict(self.mach_avail)
        ready = dict(self.job_ready_base)
        for r in self.run_ops:
            rem = r["rem_up"] if ("run", r["id"]) in zs else r["rem_nom"]
            fin = avail.get(r["machine"], 0) + rem
            avail[r["machine"]] = fin
            ready[r["job"]] = max(ready.get(r["job"], 0), fin)
        return dict(d=d, avail=avail, ready=ready)


# ---------------------------------------------------------------------------
def solve_master(win: Window, scenarios, time_limit=1.0, mode="robust",
                 hint=None, lam=(1, 1)):
    """mode: 'robust' (min lam[0]*nominalTWT + lam[1]*worst-case TWT),
    'saa' (min mean TWT), 'single'. Scenario 0 is the nominal scenario."""
    mdl = cp_model.CpModel()
    ops = win.ops
    S = len(scenarios)
    if not ops:
        return dict(assign={}, order={m: [] for st in win.stages for m in win.machines[st]},
                    obj=0, status="EMPTY", walltime=0.0, plan_start={})
    Hs = []
    for sc in scenarios:
        Hs.append(max(list(sc["avail"].values()) + list(sc["ready"].values()) + [0])
                  + sum(sc["d"].values()) + 5)
    BIG = max(Hs) + max(abs(win.jobs[j]["due"]) for j in win.jobs) + 10

    a = {}     # (oid, m) -> bool
    st = {}    # (oid, s) -> int start
    for o in ops:
        ms = win.machines[o["stage"]]
        for m in ms:
            a[(o["id"], m)] = mdl.NewBoolVar(f"a_{o['id']}_{m}")
        mdl.AddExactlyOne([a[(o["id"], m)] for m in ms])
        for s in range(S):
            st[(o["id"], s)] = mdl.NewIntVar(0, Hs[s], f"st_{o['id']}_{s}")

    by_stage = {k: [o for o in ops if o["stage"] == k] for k in win.stages}
    by_job = {}
    for o in ops:
        by_job.setdefault(o["job"], []).append(o)
    for j in by_job:
        by_job[j].sort(key=lambda o: o["stage"])

    prec = {}
    for k in win.stages:
        L = by_stage[k]
        for i in range(len(L)):
            for jdx in range(i + 1, len(L)):
                o1, o2 = L[i], L[jdx]
                p = mdl.NewBoolVar(f"p_{o1['id']}_{o2['id']}")
                prec[(o1["id"], o2["id"])] = p
                su12 = win.su(o1["rec"], o2["rec"])
                su21 = win.su(o2["rec"], o1["rec"])
                for m in win.machines[k]:
                    for s in range(S):
                        d1 = scenarios[s]["d"][o1["id"]]
                        d2 = scenarios[s]["d"][o2["id"]]
                        mdl.Add(st[(o2["id"], s)] >= st[(o1["id"], s)] + d1 + su12
                                ).OnlyEnforceIf([a[(o1["id"], m)], a[(o2["id"], m)], p])
                        mdl.Add(st[(o1["id"], s)] >= st[(o2["id"], s)] + d2 + su21
                                ).OnlyEnforceIf([a[(o1["id"], m)], a[(o2["id"], m)], p.Not()])

    # frozen commitments: fixed machine, fixed relative order, head of queue
    ops_by_id = {o["id"]: o for o in win.ops}
    for oid, (fm, _ix) in win.frozen.items():
        if (oid, fm) in a:
            mdl.Add(a[(oid, fm)] == 1)
    def _plit(oa, ob):
        return prec[(oa, ob)] if (oa, ob) in prec else prec[(ob, oa)].Not()
    fro = sorted(win.frozen.items(), key=lambda kv: kv[1][1])
    for i1 in range(len(fro)):
        o1, (m1, _) = fro[i1]
        if not any(o1 == o["id"] for o in win.ops):
            continue
        for i2 in range(i1 + 1, len(fro)):
            o2, (m2, _) = fro[i2]
            if m1 != m2 or not any(o2 == o["id"] for o in win.ops):
                continue
            mdl.AddBoolAnd([_plit(o1, o2)])
        st1 = ops_by_id[o1]["stage"]
        for o in win.ops:
            if o["stage"] == st1 and o["id"] not in win.frozen:
                mdl.AddImplication(a[(o["id"], m1)], _plit(o1, o["id"]))

    def prec_lit(oa, ob):
        """literal that is true iff op oa precedes op ob (same stage)."""
        if (oa, ob) in prec:
            return prec[(oa, ob)]
        return prec[(ob, oa)].Not()

    # exact initial-setup logic on stage-0 machines: an op with no predecessor
    # on its machine pays the changeover from the machine's current recipe.
    if win.setup is not None:
        L0 = by_stage.get(0, [])
        for o in L0:
            for m in win.machines[0]:
                su0 = win.su(win.mach_rec.get(m), o["rec"])
                if su0 <= 0:
                    continue
                haspred_lits = []
                for o2 in L0:
                    if o2["id"] == o["id"]:
                        continue
                    b = mdl.NewBoolVar(f"hp_{o['id']}_{o2['id']}_{m}")
                    # b <=> a[o2,m] AND (o2 before o)
                    mdl.AddBoolAnd([a[(o2["id"], m)], prec_lit(o2["id"], o["id"])]
                                   ).OnlyEnforceIf(b)
                    mdl.AddBoolOr([a[(o2["id"], m)].Not(),
                                   prec_lit(o2["id"], o["id"]).Not(), b])
                    haspred_lits.append(b)
                npv = mdl.NewBoolVar(f"np_{o['id']}_{m}")
                if haspred_lits:
                    hp = mdl.NewBoolVar(f"HP_{o['id']}_{m}")
                    mdl.AddMaxEquality(hp, haspred_lits)
                    mdl.Add(npv + hp == 1)
                else:
                    mdl.Add(npv == 1)
                for s in range(S):
                    av = int(scenarios[s]["avail"].get(m, 0))
                    mdl.Add(st[(o["id"], s)] >= av + su0
                            ).OnlyEnforceIf([a[(o["id"], m)], npv])

    for s in range(S):
        sc = scenarios[s]
        for o in ops:
            for m in win.machines[o["stage"]]:
                av = int(sc["avail"].get(m, 0))
                if av > 0:
                    mdl.Add(st[(o["id"], s)] >= av).OnlyEnforceIf(a[(o["id"], m)])
        for j, L in by_job.items():
            rdy = int(sc["ready"].get(j, 0))
            if rdy > 0:
                mdl.Add(st[(L[0]["id"], s)] >= rdy)
            for i in range(len(L) - 1):
                mdl.Add(st[(L[i + 1]["id"], s)] >=
                        st[(L[i]["id"], s)] + sc["d"][L[i]["id"]])

    twt = []
    for s in range(S):
        terms = []
        for j, L in by_job.items():
            last = L[-1]
            C = mdl.NewIntVar(0, Hs[s] + 5, f"C_{j}_{s}")
            mdl.Add(C == st[(last["id"], s)] + scenarios[s]["d"][last["id"]])
            T = mdl.NewIntVar(0, BIG, f"T_{j}_{s}")
            mdl.Add(T >= C - int(win.jobs[j]["due"]))
            terms.append(int(win.jobs[j]["w"]) * T)
        twt.append(cp_model.LinearExpr.sum(terms) if terms else 0)

    if mode == "robust" and S > 1:
        Z = mdl.NewIntVar(0, BIG * 20, "Z")
        for s in range(S):
            mdl.Add(Z >= twt[s])
        mdl.Minimize(lam[1] * Z + lam[0] * twt[0])
    elif mode == "saa" and S > 1:
        mdl.Minimize(cp_model.LinearExpr.sum(twt))
    else:
        mdl.Minimize(twt[0])

    if hint:
        hord = hint.get("order", {})
        hpos = {}
        for _m, _seq in hord.items():
            for _i, _oid in enumerate(_seq):
                hpos[_oid] = (_m, _i)
        for (_oa, _ob), _lit in prec.items():
            _pa, _pb = hpos.get(_oa), hpos.get(_ob)
            if _pa and _pb and _pa[0] == _pb[0]:
                mdl.AddHint(_lit, 1 if _pa[1] < _pb[1] else 0)
        for (oid, m), val in hint.get("assign_lit", {}).items():
            if (oid, m) in a:
                mdl.AddHint(a[(oid, m)], val)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(time_limit)
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 7
    t0 = time.time()
    status = solver.Solve(mdl)
    wt = time.time() - t0
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return None

    assign = {}
    for o in ops:
        for m in win.machines[o["stage"]]:
            if solver.Value(a[(o["id"], m)]):
                assign[o["id"]] = m
                break
    # priority order per machine from nominal-scenario starts
    order = {m: [] for k in win.stages for m in win.machines[k]}
    plan_start = {}
    for o in ops:
        s0 = solver.Value(st[(o["id"], 0)])
        plan_start[o["id"]] = s0
        order[assign[o["id"]]].append((s0, o["id"]))
    for m in order:
        order[m] = [oid for _, oid in sorted(order[m])]
    obj = solver.Value(twt[0]) if S == 1 or mode != "robust" else solver.ObjectiveValue()
    return dict(assign=assign, order=order, obj=obj, status=solver.StatusName(status),
                walltime=wt, plan_start=plan_start,
                wc_master=(solver.Value(Z) if (mode == "robust" and S > 1) else None))


# ---------------------------------------------------------------------------
def evaluate_fixed(win: Window, assign, order, scenario):
    """List-schedule under fixed assignment+sequence; return (TWT, C_by_job,
    starts). Semi-active w.r.t. the given per-machine sequence."""
    d = scenario["d"]
    avail = dict(scenario["avail"])
    ready = dict(scenario["ready"])
    ops_by_id = {o["id"]: o for o in win.ops}
    by_job = {}
    for o in win.ops:
        by_job.setdefault(o["job"], []).append(o)
    for j in by_job:
        by_job[j].sort(key=lambda o: o["stage"])
    pred = {}
    for j, L in by_job.items():
        for i, o in enumerate(L):
            pred[o["id"]] = L[i - 1]["id"] if i > 0 else None
    ptr = {m: 0 for m in order}
    C = {}
    starts = {}
    done = set()
    n = len(win.ops)
    cur_rec = dict(win.mach_rec)
    while len(done) < n:
        progress = False
        for m, seq in order.items():
            while ptr[m] < len(seq):
                oid = seq[ptr[m]]
                p = pred[oid]
                if p is not None and p not in C:
                    break
                o = ops_by_id[oid]
                su = win.su(cur_rec.get(m), o["rec"]) if o["stage"] == 0 else 0
                rj = ready.get(o["job"], 0)
                est = max(avail.get(m, 0) + su, rj if p is None else 0,
                          C[p] if p is not None else 0)
                starts[oid] = est
                C[oid] = est + d[oid]
                avail[m] = C[oid]
                if o["stage"] == 0:
                    cur_rec[m] = o["rec"]
                done.add(oid)
                ptr[m] += 1
                progress = True
        if not progress:
            raise RuntimeError("evaluate_fixed deadlock")
    twt = 0
    Cj = {}
    for j, L in by_job.items():
        Cj[j] = C[L[-1]["id"]]
        twt += win.jobs[j]["w"] * max(0, Cj[j] - win.jobs[j]["due"])
    return twt, Cj, starts


# ---------------------------------------------------------------------------
def adversary(win: Window, assign, order, Gamma, enum_cap=5000):
    """max_{|z|<=Gamma} TWT under fixed decisions. Exact enum if small,
    else greedy + 1-swap. Returns (best_twt, best_zset, exact_flag)."""
    units = win.uncertain_units()
    U = [(k, i) for (k, i, dlt) in units]
    if not U or Gamma <= 0:
        twt, _, _ = evaluate_fixed(win, assign, order, win.scenario(set()))
        return twt, set(), True
    G = min(Gamma, len(U))

    def val(zs):
        twt, _, _ = evaluate_fixed(win, assign, order, win.scenario(zs))
        return twt

    n_comb = sum(math.comb(len(U), g) for g in range(G, G + 1))
    if n_comb <= enum_cap:
        best, bz = -1, set()
        for comb in itertools.combinations(U, G):
            v = val(set(comb))
            if v > best:
                best, bz = v, set(comb)
        v0 = val(set())
        if v0 > best:
            best, bz = v0, set()
        return best, bz, True

    # greedy
    cur = set()
    cur_v = val(cur)
    remaining = set(U)
    for _ in range(G):
        best_u, best_v = None, cur_v
        for u in remaining:
            v = val(cur | {u})
            if v > best_v:
                best_v, best_u = v, u
        if best_u is None:
            # ties/no gain: still fill budget with largest delta (worst-case set)
            dmap = {(k, i): dlt for (k, i, dlt) in units}
            rest = sorted(remaining, key=lambda u: -dmap[u])
            if rest:
                best_u, best_v = rest[0], val(cur | {rest[0]})
            else:
                break
        cur.add(best_u)
        remaining.discard(best_u)
        cur_v = best_v
    # 1-swap
    improved = True
    it = 0
    while improved and it < 2:
        improved = False
        it += 1
        for u_in in list(cur):
            for u_out in list(set(U) - cur):
                v = val((cur - {u_in}) | {u_out})
                if v > cur_v:
                    cur = (cur - {u_in}) | {u_out}
                    cur_v = v
                    improved = True
                    break
            if improved:
                break
    return cur_v, cur, False


# ---------------------------------------------------------------------------
def heuristic_scenario(win: Window, Gamma):
    """initial adversarial guess: inflate the Gamma units with largest
    delta * job weight."""
    units = win.uncertain_units()
    jw = {o["id"]: win.jobs[o["job"]]["w"] for o in win.ops}
    for r in win.run_ops:
        jw[r["id"]] = win.jobs.get(r["job"], {"w": 1})["w"] if r["job"] in win.jobs else 1
    scored = sorted(units, key=lambda u: -(u[2] * jw.get(u[1], 1)))
    z = {(k, i) for (k, i, _) in scored[:Gamma]}
    return z


def ccg_solve(win: Window, Gamma, time_limit=1.0, max_add=2, eps=1,
              lam=(1, 1)):
    """Anytime column-and-constraint generation for one window.
    Every candidate plan (warm start and each master incumbent) is scored by
    its TRUE blend lam[0]*nominal + lam[1]*worst-case, where the worst case
    is computed by the exact/greedy budget adversary; the best-scoring plan
    seen is returned. This makes the procedure monotone in the certified
    objective even when individual masters hit their time limit."""
    scen = [win.scenario(set())]
    if Gamma > 0 and win.uncertain_units():
        scen.append(win.scenario(heuristic_scenario(win, Gamma)))
    info = dict(iters=0, adv_exact=[], master_time=0.0, adv_time=0.0)
    hint = solve_master(win, [scen[0]], time_limit=min(0.5, time_limit),
                        mode="single")
    best = None
    best_score = None

    def _track(cand):
        nonlocal best, best_score
        nom, _, _ = evaluate_fixed(win, cand["assign"], cand["order"],
                                   win.scenario(set()))
        t0 = time.time()
        wc, zset, exact = adversary(win, cand["assign"], cand["order"], Gamma)
        info["adv_time"] += time.time() - t0
        info["adv_exact"].append(exact)
        sc = lam[0] * nom + lam[1] * wc
        if best_score is None or sc < best_score - 1e-9:
            best_score = sc
            best = cand
            best["wc_true"] = wc
        return wc, zset

    if hint is not None:
        _track(hint)
    U = set(u[:2] for u in win.uncertain_units())
    if U:
        box = solve_master(win, [win.scenario(U)],
                           time_limit=min(0.5, time_limit), mode="single")
        if box is not None:
            _track(box)
    sol = hint
    for it in range(max_add + 1):
        sol = solve_master(win, scen, time_limit=time_limit, mode="robust",
                           hint=best or hint)
        if sol is None:
            break
        info["iters"] += 1
        info["master_time"] += sol["walltime"]
        wc, zset = _track(sol)
        if it == max_add or Gamma == 0:
            break
        zmaster = (sol["wc_master"] if sol.get("wc_master") is not None
                   else sol["obj"])
        if wc > zmaster + eps:
            scen.append(win.scenario(zset))
        else:
            break
    return (best if best is not None else sol), info

def polish(win: Window, sol, Gamma, lam=(1, 1), rounds=4, budget_s=8.0):
    """Adversarial-descent polish: first-improvement local search on the
    incumbent plan, scored by the exact/greedy budget adversary. Moves:
    within-machine adjacent swaps and front-insertions on the last stage,
    cross-machine swaps and adjacent swaps on stage 0."""
    import copy as _copy
    t_end = time.time() + budget_s
    assign = dict(sol["assign"])
    order = {m: list(v) for m, v in sol["order"].items()}

    def score(a, o):
        nom, _, _ = evaluate_fixed(win, a, o, win.scenario(set()))
        wc, _, _ = adversary(win, a, o, Gamma)
        return lam[0] * nom + lam[1] * wc, nom, wc

    best, bnom, bwc = score(assign, order)
    last = win.stages[-1]
    st0 = win.stages[0]
    improved = True
    r = 0
    while improved and r < rounds and time.time() < t_end:
        improved = False
        r += 1
        cands = []
        for m in win.machines[last]:
            seq = order[m]
            for i in range(len(seq) - 1):
                cands.append(("swap", m, i))
            for i in range(2, len(seq)):
                cands.append(("front", m, i))
        for m in win.machines[st0]:
            seq = order[m]
            for i in range(len(seq) - 1):
                cands.append(("swap", m, i))
        m0s = win.machines[st0]
        pos = [(m, i) for m in m0s for i in range(len(order[m]))]
        for x in range(len(pos)):
            for y in range(x + 1, len(pos)):
                if pos[x][0] != pos[y][0]:
                    cands.append(("xswap", pos[x], pos[y]))
        for c in cands:
            if time.time() > t_end:
                break
            o2 = {m: list(v) for m, v in order.items()}
            a2 = dict(assign)
            if c[0] == "swap":
                _, m, i = c
                o2[m][i], o2[m][i + 1] = o2[m][i + 1], o2[m][i]
            elif c[0] == "front":
                _, m, i = c
                o2[m].insert(0, o2[m].pop(i))
            else:
                _, (m1, i1), (m2, i2) = c
                u, v = o2[m1][i1], o2[m2][i2]
                o2[m1][i1], o2[m2][i2] = v, u
                a2[(u, m1)], a2[(u, m2)] = 0, 1
                a2[(v, m2)], a2[(v, m1)] = 0, 1
            try:
                s2, n2, w2 = score(a2, o2)
            except Exception:
                continue
            if s2 < best - 1e-9:
                best, bnom, bwc = s2, n2, w2
                order, assign = o2, a2
                improved = True
                break
    out = dict(sol)
    out["assign"] = assign
    out["order"] = order
    out["polish_obj"] = best
    return out
