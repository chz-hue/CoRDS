"""Central, overridable filesystem layout.

Every location can be overridden with an environment variable so the
package never hard-codes user-specific absolute paths:

    CORDS_ROOT        repository root (default: two levels above this file)
    CORDS_DATA_RAW    raw NASA .mat files      (default: <root>/data/raw)
    CORDS_DATA_PROC   extracted operation CSVs (default: <root>/data/processed)
    CORDS_RESULTS     experiment logs + models (default: <root>/results)
    CORDS_PAPER_OUT   generated figs/tabs      (default: <root>/outputs_paper)
"""
import os
from pathlib import Path

ROOT = Path(os.environ.get(
    "CORDS_ROOT", Path(__file__).resolve().parents[2]))


def _p(env, default):
    return Path(os.environ.get(env, str(default)))


DATA_RAW_DIR = _p("CORDS_DATA_RAW", ROOT / "data" / "raw")
DATA_PROC_DIR = _p("CORDS_DATA_PROC", ROOT / "data" / "processed")
RESULTS_DIR = _p("CORDS_RESULTS", ROOT / "results")
PAPER_OUT_DIR = _p("CORDS_PAPER_OUT", ROOT / "outputs_paper")


def ensure_dirs():
    for d in (DATA_PROC_DIR, RESULTS_DIR,
              PAPER_OUT_DIR / "tabs", PAPER_OUT_DIR / "figs"):
        d.mkdir(parents=True, exist_ok=True)
