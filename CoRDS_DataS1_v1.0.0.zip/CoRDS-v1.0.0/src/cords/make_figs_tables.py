"""Generate all paper tables (LaTeX) and figures (PDF) from results CSVs.
Every number in the paper is produced here; nothing is hand-typed."""
import os
import sys
import numpy as np
from cords.paths import RESULTS_DIR, PAPER_OUT_DIR, DATA_PROC_DIR, ensure_dirs
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon

from cords.ml_uq import gamma_budget  # noqa: E402

R = str(RESULTS_DIR)
P = str(PAPER_OUT_DIR)
os.makedirs(f"{P}/figs", exist_ok=True)
os.makedirs(f"{P}/tabs", exist_ok=True)

plt.rcParams.update({"font.size": 8.5, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 150})
MACROS = {}


DIGIT = {"0": "Zero", "1": "One", "2": "Two", "3": "Three", "4": "Four",
         "5": "Five", "6": "Six", "7": "Seven", "8": "Eight", "9": "Nine"}


def macro(name, val):
    name = "".join(DIGIT.get(ch, ch) for ch in name)
    MACROS[name] = val


def fmt(v, d=1):
    return f"{v:.{d}f}"


def stars(p):
    return "$^{***}$" if p < 0.001 else "$^{**}$" if p < 0.01 else \
        "$^{*}$" if p < 0.05 else ""


def w_test(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 5 or np.allclose(a, b):
        return 1.0
    try:
        return wilcoxon(a, b).pvalue
    except ValueError:
        return 1.0


# ==================================================================== RQ1
def rq1():
    df = pd.read_csv(f"{R}/rq1_uq.csv")
    on = pd.read_csv(f"{R}/rq1_online.csv")
    M = {"CQR-Mondrian (ours)": "ours", "CQR-global": "glob",
         "QR (no conformal)": "qr", "Empirical quantile": "emp"}
    lines = [r"\begin{tabular}{llcccccccc}", r"\toprule",
             r" & & \multicolumn{3}{c}{CQR--Mondrian (ours)} & "
             r"\multicolumn{2}{c}{CQR--global} & "
             r"\multicolumn{2}{c}{QR, no conformal} & Emp.\\",
             r"\cmidrule(lr){3-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}"
             r"\cmidrule(lr){10-10}",
             r"Split & Op. & Cov. & Grp-min & Marg. & Grp-min & Marg. & "
             r"Cov. & Marg. & Marg.\\ \midrule"]
    ratios = []
    for split in ("op", "cell"):
        for tgt in ("charge", "discharge"):
            s = df[(df.split == split) & (df.target == tgt)]
            r_ = {M[m]: s[s.method == m].iloc[0]
                  for m in M if len(s[s.method == m])}
            sp = "random" if split == "op" else "by-cell"
            ratios.append(r_["emp"].margin_upper / r_["ours"].margin_upper)
            lines.append(
                f"{sp} & {tgt} & {r_['ours'].cov_upper:.3f} & "
                f"{r_['ours'].cov_upper_min_group:.3f} & "
                f"{r_['ours'].margin_upper:.0f} & "
                f"{r_['glob'].cov_upper_min_group:.3f} & "
                f"{r_['glob'].margin_upper:.0f} & "
                f"{r_['qr'].cov_upper:.3f} & {r_['qr'].margin_upper:.0f} & "
                f"{r_['emp'].margin_upper:.0f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_uq.tex", "w").write("\n".join(lines))
    d = df[(df.split == "cell") & (df.method == "CQR-Mondrian (ours)")]
    macro("CovChargeCell",
          fmt(d[d.target == "charge"].cov_upper.iloc[0], 3))
    macro("CovDischargeCell",
          fmt(d[d.target == "discharge"].cov_upper.iloc[0], 3))
    macro("WidthRatioMax", fmt(max(ratios), 1))
    macro("WidthRatioMin", fmt(min(ratios), 1))
    dg = df[(df.split == "cell")]
    macro("GrpMinOursCell", fmt(dg[dg.method == "CQR-Mondrian (ours)"]
                                .cov_upper_min_group.min(), 2))
    macro("GrpMinGlobCell", fmt(dg[dg.method == "CQR-global"]
                                .cov_upper_min_group.min(), 2))

    lines = [r"\begin{tabular}{lcccccc}", r"\toprule",
             r" & \multicolumn{3}{c}{Charge} & "
             r"\multicolumn{3}{c}{Discharge}\\",
             r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}",
             r"Method & Cov. & Cov.\,2nd half & Marg. & Cov. & "
             r"Cov.\,2nd half & Marg.\\ \midrule"]
    lab = {"static CQR": "Static conformal",
           "online-adaptive (ours)": "Online (OGD, ours)"}
    for m, name in lab.items():
        r1 = on[(on.method == m) & (on.target == "charge")].iloc[0]
        r2 = on[(on.method == m) & (on.target == "discharge")].iloc[0]
        lines.append(f"{name} & {r1.cov_all:.3f} & {r1.cov_secondhalf:.3f} &"
                     f" {r1.mean_margin:.0f} & {r2.cov_all:.3f} & "
                     f"{r2.cov_secondhalf:.3f} & {r2.mean_margin:.0f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_online.tex", "w").write("\n".join(lines))
    st = on[on.method == "static CQR"]
    macro("CovShiftStaticMin", fmt(st.cov_all.min(), 2))
    onl = on[on.method == "online-adaptive (ours)"]
    macro("CovShiftOnlineMin", fmt(onl.cov_all.min(), 2))
    macro("CovShiftOnlineSecond", fmt(onl.cov_secondhalf.min(), 2))


# ============================================================ data figure
def fig_data():
    dd = pd.read_csv(DATA_PROC_DIR / "ops_discharge.csv")
    dc = pd.read_csv(DATA_PROC_DIR / "ops_charge.csv")
    fig, ax = plt.subplots(1, 2, figsize=(6.2, 2.2))
    rng = np.random.default_rng(0)
    for lab_, (a, d, ttl) in zip("AB", ((ax[0], dc, "Charge (formation) ops"),
                      (ax[1], dd, "Discharge (EOL test) ops"))):
        a.text(-0.14, 1.06, lab_, transform=a.transAxes, fontsize=12,
               fontweight="bold", va="top")
        x = d.ambient_T + rng.normal(0, .35, len(d))
        a.scatter(x, d.y_duration_s / 60, s=2.5, alpha=.25, lw=0, c="#1f5fa8")
        a.set_xlabel("Ambient temperature (°C)")
        a.set_title(ttl, fontsize=9)
    ax[0].set_ylabel("Duration (min)")
    fig.tight_layout()
    fig.savefig(f"{P}/figs/fig_data.pdf", bbox_inches="tight")
    plt.close(fig)
    g = dd.groupby("ambient_T").y_duration_s.agg(["count", "mean", "std"])
    g = g[g["count"] >= 100]
    tight = g.loc[g["std"].idxmin()]
    wild = g.loc[g["std"].idxmax()]
    macro("DisTightT", fmt(g["std"].idxmin(), 0))
    macro("DisWildT", fmt(g["std"].idxmax(), 0))
    macro("DisTightMean", fmt(tight["mean"] / 60, 0))
    macro("DisTightStd", fmt(tight["std"] / 60, 1))
    macro("DisWildMean", fmt(wild["mean"] / 60, 0))
    macro("DisWildStd", fmt(wild["std"] / 60, 0))
    macro("NOpsCharge", str(len(dc)))
    macro("NOpsDischarge", str(len(dd)))


# ================================================================= bench
ORDER = ["ORACLE", "DET", "SAA", "P90", "FIXG", "NOML", "NOCONF", "NOCCG",
         "CORDS"]
NAME = dict(ORACLE="ORACLE", DET="DET",
            SAA="SAA", P90="P90",
            FIXG="FixG", NOML="NoML",
            NOCONF="NoConf", NOCCG="NoCCG",
            CORDS="CoRDS")


def bench_tables():
    df = pd.read_csv(f"{R}/bench_main.csv")
    df["terc"] = pd.qcut(df.groupby("w").K.transform("first"), 3,
                         labels=["light", "medium", "heavy"])
    piv = {}
    for terc in ("light", "medium", "heavy"):
        piv[terc] = df[df.terc == terc]

    def paired(dsub, meth, col):
        a = dsub[dsub.method == meth].sort_values("w")[col].values
        b = dsub[dsub.method == "CORDS"].sort_values("w")[col].values
        n = min(len(a), len(b))
        return w_test(a[:n], b[:n])

    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
             r" & \multicolumn{3}{c}{Medium congestion} & "
             r"\multicolumn{3}{c}{Heavy congestion}\\",
             r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}",
             r"Method & Nom. & WC$_{\mathrm{audit}}$ & Real. & "
             r"Nom. & WC$_{\mathrm{audit}}$ & Real.\\ \midrule"]
    for m in ORDER:
        vals = []
        for terc in ("medium", "heavy"):
            d = piv[terc]
            s = d[d.method == m]
            for col in ("nom_twt", "wc_audit", "real_twt"):
                v = s[col].mean()
                star = ""
                if m != "CORDS" and col in ("wc_audit", "real_twt"):
                    star = stars(paired(d, m, col))
                vals.append(f"{v:.0f}{star}")
        lines.append(f"{NAME[m]} & " + " & ".join(vals) + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_bench.tex", "w").write("\n".join(lines))

    hv = piv["heavy"]
    for m in ("DET", "P90", "CORDS", "ORACLE", "SAA"):
        s = hv[hv.method == m]
        macro(f"H{m.title()}Wc", fmt(s.wc_audit.mean(), 0))
        macro(f"H{m.title()}Real", fmt(s.real_twt.mean(), 0))
        macro(f"H{m.title()}Nom", fmt(s.nom_twt.mean(), 0))
    macro("HWcGapDet", fmt(hv[hv.method == "DET"].wc_audit.mean()
                           - hv[hv.method == "CORDS"].wc_audit.mean(), 0))
    macro("PWcDetCords", f"{paired(hv, 'DET', 'wc_audit'):.1e}")
    macro("PRealP90Cords", f"{paired(hv, 'P90', 'real_twt'):.1e}")
    macro("NWindows", str(df.w.nunique()))
    cv = df.dropna(subset=["cert_viol"]).groupby("method").cert_viol.mean()
    macro("CertViolCords", fmt(cv.get("CORDS", np.nan), 3))
    macro("CertViolNoconf", fmt(cv.get("NOCONF", np.nan), 3))
    macro("CertViolNoml", fmt(cv.get("NOML", np.nan), 3))
    exact = df[df.method == "CORDS"].wc_exact.mean()
    macro("AdvExactPct", fmt(100 * exact, 0))

    # Prop 2 empirical: P(exceed > Gamma) vs beta
    per_w = df.groupby("w").first()
    viol = (per_w.exceed > per_w.Gamma).mean()
    macro("PropTwoEmp", fmt(viol, 3))
    fig, ax = plt.subplots(1, 2, figsize=(6.2, 2.15))
    for lab_, a_ in zip("AB", ax):
        a_.text(-0.16, 1.08, lab_, transform=a_.transAxes, fontsize=12,
                fontweight="bold", va="top")
    Ks = sorted(per_w.K.unique())
    emp = [(per_w[per_w.K == k].exceed > per_w[per_w.K == k].Gamma).mean()
           for k in Ks]
    cnt = [len(per_w[per_w.K == k]) for k in Ks]
    ax[0].bar(Ks, emp, color="#1f5fa8", width=.8)
    ax[0].axhline(0.1, color="crimson", ls="--", lw=1,
                  label=r"$\beta=0.1$")
    ax[0].set_xlabel(r"window size $K$ (uncertain ops)")
    ax[0].set_ylabel(r"$\hat{P}(\#\{\hat p_e > \hat u_e\} > \Gamma)$")
    ax[0].legend(frameon=False)
    Kg = np.arange(1, 41)
    for a_, c in ((0.05, "#777777"), (0.1, "#1f5fa8"), (0.2, "#c05020")):
        ax[1].step(Kg, [gamma_budget(int(k), a_, 0.1) for k in Kg],
                   where="mid", label=fr"$\alpha={a_}$", color=c, lw=1.3)
    ax[1].plot(Kg, Kg, color="#bbbbbb", ls=":", lw=1, label=r"box ($\Gamma=K$)")
    ax[1].set_xlabel(r"$K$")
    ax[1].set_ylabel(r"calibrated budget $\Gamma(K,\alpha,\beta)$")
    ax[1].legend(frameon=False, fontsize=7.5)
    fig.tight_layout()
    fig.savefig(f"{P}/figs/fig_prop2.pdf", bbox_inches="tight")
    plt.close(fig)
    return df


def fig_frontier(bmain):
    hv_w = bmain.groupby("w").K.first().sort_values(ascending=False)
    heavy_ws = set(hv_w.index[:32])          # same 32 windows as lambda sweep
    hv = bmain[bmain.w.isin(heavy_ws)]
    pts = {}
    for m in ("ORACLE", "DET", "SAA", "P90", "CORDS"):
        s = hv[hv.method == m]
        pts[m] = (s.nom_twt.mean(), s.wc_audit.mean())
    macro("FrontCordsNom", fmt(pts["CORDS"][0], 0))
    macro("FrontCordsWc", fmt(pts["CORDS"][1], 0))
    lam_pts = []
    if os.path.exists(f"{R}/bench_lambda.csv"):
        bl = pd.read_csv(f"{R}/bench_lambda.csv")
        for tag, g in bl.groupby("tag"):
            lam_pts.append((tag, g.nom_twt.mean(), g.wc_audit.mean()))
            macro("Lam" + tag.replace("lam", "").replace("_", ""),
                  f"({g.nom_twt.mean():.0f}, {g.wc_audit.mean():.0f})")
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    mk = dict(ORACLE=("*", "#333333"), DET=("s", "#c05020"),
              SAA=("D", "#777777"), P90=("^", "#2a7f3f"),
              CORDS=("o", "#1f5fa8"))
    for m, (x, y) in pts.items():
        ax.scatter(x, y, marker=mk[m][0], color=mk[m][1], s=45, zorder=3,
                   label=NAME[m].replace("\\textsc{", "").replace("}", ""))
    if lam_pts:
        lp = sorted(lam_pts, key=lambda t: t[1])
        xs = [p[1] for p in lp] + [pts["CORDS"][0]]
        ys = [p[2] for p in lp] + [pts["CORDS"][1]]
        o = np.argsort(xs)
        ax.plot(np.array(xs)[o], np.array(ys)[o], color="#1f5fa8", lw=1,
                ls="--", alpha=.7, zorder=2, label=r"$\lambda$-sweep")
    ax.set_xlabel("nominal TWT (min, mean over 32 heaviest windows)")
    ax.set_ylabel("certified worst-case TWT")
    ax.legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(f"{P}/figs/fig_frontier.pdf", bbox_inches="tight")
    plt.close(fig)


# ============================================================== main loop
def main_loop():
    df = pd.read_csv(f"{R}/main_loop.csv")
    pols = ["FIFO", "SPT", "EDD", "ATC", "ATCS", "DET", "P90", "SAA",
            "CORDS", "ORACLE"]
    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
             r"Policy & TWT & On-time & On-time & $P95$ tard. & Plan "
             r"& Solver\\",
             r" & (min) & (\%) & $w{=}5$ (\%) & (min) & churn & "
             r"(s/replan)\\ "
             r"\midrule"]
    base = df[df.policy == "DET"].sort_values("seed")
    for p in pols:
        s = df[df.policy == p].sort_values("seed")
        if not len(s):
            continue
        star = ""
        if p not in ("DET",):
            n = min(len(s), len(base))
            star = stars(w_test(s.twt.values[:n], base.twt.values[:n]))
        lines.append(
            f"{p if p not in NAME else NAME[p]} & {s.twt.mean():.0f}"
            f"$\\pm${s.twt.std():.0f}{star} & {100*s.on_time.mean():.0f} & "
            f"{100*s.ot_w5.mean():.0f} & {s.p95_tard.mean():.0f} & "
            f"{s.nerv.mean():.1f} & "
            f"{(s.solver_s / s.n_replans.clip(lower=1)).mean():.2f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_main.tex", "w").write("\n".join(lines))
    g = df.groupby("policy")
    for p in pols:
        if p in g.groups:
            macro(f"Loop{p.title()}Twt", fmt(g.get_group(p).twt.mean(), 0))
            macro(f"Loop{p.title()}Ot", fmt(100 * g.get_group(p).on_time.mean(), 0))
    b = g.get_group("DET").sort_values("seed")
    c = g.get_group("CORDS").sort_values("seed")
    n = min(len(b), len(c))
    macro("PLoopDetCords", f"{w_test(b.twt.values[:n], c.twt.values[:n]):.2f}")
    best_rule = min(("FIFO", "SPT", "EDD", "ATC", "ATCS"),
                    key=lambda p: g.get_group(p).twt.mean())
    macro("BestRule", best_rule)
    macro("RuleGapPct", fmt(100 * (g.get_group(best_rule).twt.mean()
                                   / g.get_group("CORDS").twt.mean() - 1), 0))
    macro("LoopCordsSolve",
          fmt((c.solver_s / c.n_replans.clip(lower=1)).mean(), 2))
    macro("LoopReplans", fmt(c.n_replans.mean(), 0))


def drift():
    df = pd.read_csv(f"{R}/drift_loop.csv")
    pols = ["ATCS", "DET", "P90", "CORDS", "CORDS_online"]
    nm = dict(CORDS_online="CoRDS-online")
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Policy & TWT (min) & On-time (\%) & On-time $w{=}5$ (\%) & "
             r"$P95$ tard.\\ \midrule"]
    base = df[df.policy == "CORDS_online"].sort_values("seed")
    for p in pols:
        s = df[df.policy == p].sort_values("seed")
        if not len(s):
            continue
        star = ""
        if p != "CORDS_online":
            n = min(len(s), len(base))
            star = stars(w_test(s.twt.values[:n], base.twt.values[:n]))
        lines.append(f"{nm.get(p, NAME.get(p, p))} & "
                     f"{s.twt.mean():.0f}$\\pm${s.twt.std():.0f}{star} & "
                     f"{100*s.on_time.mean():.0f} & {100*s.ot_w5.mean():.0f}"
                     f" & {s.p95_tard.mean():.0f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_drift.tex", "w").write("\n".join(lines))
    g = df.groupby("policy")
    for p, k in (("DET", "DriftDet"), ("CORDS", "DriftCords"),
                 ("CORDS_online", "DriftOnline")):
        if p in g.groups:
            macro(f"{k}Twt", fmt(g.get_group(p).twt.mean(), 0))
            macro(f"{k}Ot", fmt(100 * g.get_group(p).on_time.mean(), 0))


def sens():
    df = pd.read_csv(f"{R}/sens_loop.csv")
    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
             r" & \multicolumn{3}{c}{DET} & "
             r"\multicolumn{3}{c}{\textsc{CoRDS}}\\",
             r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}",
             r"Scenario & TWT & OT (\%) & OT$_{w5}$ & TWT & OT (\%) & "
             r"OT$_{w5}$\\ \midrule"]
    for tag in sorted(df.tag.unique()):
        s0 = df[df.tag == tag]
        pretty = (tag.replace("su_su_scale", "setup $\\times$")
                  .replace("mtbf_mtbf", "MTBF ")
                  .replace("load_mean_ia", "load: ia ")
                  .replace("_due_base", ", due "))
        pretty = pretty.replace("1e+18", "$\\infty$").replace(".0", "")
        a = s0[s0.policy == "DET"].sort_values("seed")
        b = s0[s0.policy == "CORDS"].sort_values("seed")
        n = min(len(a), len(b))
        star = stars(w_test(a.twt.values[:n], b.twt.values[:n]))
        lines.append(
            f"{pretty} & {a.twt.mean():.0f}{star} & "
            f"{100*a.on_time.mean():.0f} & {100*a.ot_w5.mean():.0f} & "
            f"{b.twt.mean():.0f} & {100*b.on_time.mean():.0f} & "
            f"{100*b.ot_w5.mean():.0f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_sens.tex", "w").write("\n".join(lines))
    su2 = df[df.tag.str.startswith("su_su_scale2")]
    macro("SensSuTwoDet", fmt(su2[su2.policy == "DET"].twt.mean(), 0))
    macro("SensSuTwoCords", fmt(su2[su2.policy == "CORDS"].twt.mean(), 0))
    a = su2[su2.policy == "DET"].sort_values("seed").twt.values
    b = su2[su2.policy == "CORDS"].sort_values("seed").twt.values
    n = min(len(a), len(b))
    macro("PSensSuTwo", fmt(w_test(a[:n], b[:n]), 2))


def alpha_lambda():
    if not os.path.exists(f"{R}/bench_alpha.csv"):
        return
    ba = pd.read_csv(f"{R}/bench_alpha.csv")
    bm = pd.read_csv(f"{R}/bench_main.csv")
    hv_w = bm.groupby("w").K.first().sort_values(ascending=False)
    top48 = set(hv_w.index[:48])
    bm01 = bm[bm.method.isin(("DET", "P90", "CORDS")) & bm.w.isin(top48)].copy()
    bm01["tag"] = "a0.1"
    ba = pd.concat([ba, bm01])
    lines = [r"\begin{tabular}{llrrrr}", r"\toprule",
             r"$\alpha$ & Method & $\Gamma$ (med.) & Nom. & "
             r"WC$_{\mathrm{audit}}$ & Real.\\ \midrule"]
    for tag in ("a0.05", "a0.1", "a0.2"):
        s0 = ba[ba.tag == tag]
        for m in ("DET", "P90", "CORDS"):
            s = s0[s0.method == m]
            if not len(s):
                continue
            lines.append(f"{tag[1:]} & {NAME[m]} & {s.Gamma.median():.0f} & "
                         f"{s.nom_twt.mean():.0f} & {s.wc_audit.mean():.0f} &"
                         f" {s.real_twt.mean():.0f}\\\\")
        lines.append(r"\addlinespace[2pt]")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_alpha.tex", "w").write("\n".join(lines))


def scale():
    if not os.path.exists(f"{R}/scale.csv"):
        return
    df = pd.read_csv(f"{R}/scale.csv")
    df["bin"] = pd.cut(df.n_ops, bins=[0, 32, 42, 60],
                       labels=["$\\le$32", "33--42", "43+"])
    g = df.groupby("bin", observed=True).agg(
        n=("n_ops", "size"), ops=("n_ops", "mean"), K=("K", "mean"),
        G=("Gamma", "mean"), t=("solve_s", "mean"),
        tmax=("solve_s", "max"), ex=("wc_exact", "mean")).reset_index()
    lines = [r"\begin{tabular}{lrrrrrrr}", r"\toprule",
             r"Window size & $n$ & mean ops & mean $K$ & mean $\Gamma$ & "
             r"mean time (s) & max time (s) & exact adv. (\%)\\ \midrule"]
    for _, r_ in g.iterrows():
        lines.append(f"{r_['bin']} & {r_.n:.0f} & {r_.ops:.0f} & {r_.K:.0f}"
                     f" & {r_.G:.1f} & {r_.t:.1f} & {r_.tmax:.1f} & "
                     f"{100*r_.ex:.0f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_scale.tex", "w").write("\n".join(lines))
    macro("ScaleMaxOps", fmt(df.n_ops.max(), 0))
    macro("ScaleMaxT", fmt(df.solve_s.max(), 1))
    macro("ScaleExactBig", fmt(100 * df[df.n_ops > 42].wc_exact.mean(), 0))


def gamma_table():
    lines = [r"\begin{tabular}{r|rrrr}", r"\toprule",
             r"$K$ & $\Gamma_{\alpha=.05}$ & $\Gamma_{\alpha=.1}$ & "
             r"$\Gamma_{\alpha=.2}$ & box\\ \midrule"]
    for K in (6, 12, 18, 24, 36):
        lines.append(f"{K} & {gamma_budget(K, .05, .1)} & "
                     f"{gamma_budget(K, .1, .1)} & "
                     f"{gamma_budget(K, .2, .1)} & {K}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(f"{P}/tabs/tab_gamma.tex", "w").write("\n".join(lines))
    macro("GamTwelve", str(gamma_budget(12, .1, .1)))
    macro("GamTwentyFour", str(gamma_budget(24, .1, .1)))


def write_macros():
    with open(f"{P}/numbers.tex", "w") as f:
        for k, v in MACROS.items():
            f.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")


def main():
    ensure_dirs()
    done = []
    for name, fn, req in [
            ("rq1", rq1, ["rq1_uq.csv", "rq1_online.csv"]),
            ("fig_data", fig_data, []),
            ("gamma", gamma_table, []),
            ("bench", None, ["bench_main.csv"]),
            ("main_loop", main_loop, ["main_loop.csv"]),
            ("drift", drift, ["drift_loop.csv"]),
            ("sens", sens, ["sens_loop.csv"]),
            ("alpha", alpha_lambda, ["bench_alpha.csv"]),
            ("scale", scale, ["scale.csv"])]:
        if all(os.path.exists(f"{R}/{x}") for x in req):
            try:
                if name == "bench":
                    bm = bench_tables()
                    fig_frontier(bm)
                else:
                    fn()
                done.append(name)
            except Exception as e:
                print(f"[skip {name}] {type(e).__name__}: {e}")
        else:
            print(f"[waiting {name}] missing {req}")
    for k, v in (("ScaleMaxOps", "--"), ("ScaleMaxT", "--")):
        MACROS.setdefault(k, v)
    write_macros()
    print("generated:", done)


if __name__ == "__main__":
    main()
