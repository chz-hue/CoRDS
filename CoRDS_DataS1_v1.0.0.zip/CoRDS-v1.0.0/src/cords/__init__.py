"""CoRDS: Conformal-Robust Dynamic Scheduling.

Note on naming: the method is called "CoRDS" in the paper; machine-readable
policy keys inside result CSVs and code use the uppercase identifier
"CORDS" (likewise DET, P90, SAA, ORACLE, ...). Display-name mapping lives
in cords.make_figs_tables.NAME.
"""
__version__ = "1.0.0"
DISPLAY_NAME = "CoRDS"

# Backward-compatibility aliases so that artifacts pickled by the original
# flat-module layout (results/uq_*.pkl, results/*windows*.pkl.gz) load
# unchanged. The shipped artifacts are byte-identical to the runs behind
# the paper; these aliases only affect module lookup during unpickling.
import sys as _sys
from cords import ml_uq as _ml_uq, sched_core as _sched_core, \
    simulator as _simulator, bench as _bench
for _n, _m in (("ml_uq", _ml_uq), ("sched_core", _sched_core),
               ("simulator", _simulator), ("bench", _bench)):
    _sys.modules.setdefault(_n, _m)
del _sys, _ml_uq, _sched_core, _simulator, _bench, _n, _m
