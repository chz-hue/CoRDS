"""
bench.py -- window-level certification benchmark.
For realistic decision windows harvested from closed-loop trajectories,
each planning method produces a plan; every plan is then audited under the
SAME conformal-calibrated budget uncertainty set:
  nominal cost | worst-case (audit) cost | realized cost (true durations)
plus each robust method's self-certificate and its empirical validity.
"""
import copy
import gzip
import pickle
import time
import numpy as np
import pandas as pd
from cords.ml_uq import gamma_budget
from cords.sched_core import solve_master, ccg_solve, adversary, evaluate_fixed, polish
from cords.simulator import Sim, fit_uq, gen_instance


# ---------------------------------------------------------------- collect
def collect_windows(uq, seeds, cfg=None, cap_per_inst=35, jitter=1):
    snaps = []
    for sd in seeds:
        inst = gen_instance(sd, uq, cfg)
        sim = Sim(inst, "SNAP", uq, cfg)
        sim.snapshot = True
        sim.run()
        got = sim.snapshots or []
        step = max(1, len(got) // cap_per_inst)
        snaps.extend(got[::step][:cap_per_inst])
    return snaps


# ---------------------------------------------------------------- variants
def make_variant(snap, method, alpha, uq):
    """Return (window copy with method's duration model, own_uncertain?)."""
    win = copy.deepcopy(snap["win"])
    aux = snap["aux"]
    for o in win.ops:
        a = aux[o["id"]]
        pn = a["pn"]
        if a["stage"] == 1:
            o["d_nom"] = o["d_up"] = int(round(pn))
            o["uncertain"] = False
            continue
        up = a["up"][alpha]
        raw = a["raw"][alpha]
        tgt = "charge" if a["stage"] == 0 else "discharge"
        if method == "ORACLE":
            o["d_nom"] = o["d_up"] = int(max(1, round(a["true"])))
            o["uncertain"] = False
        elif method == "DET":
            o["d_nom"] = o["d_up"] = int(max(1, round(pn)))
            o["uncertain"] = False
        elif method == "P90":
            v = int(max(1, round(max(pn, up))))
            o["d_nom"] = o["d_up"] = v
            o["uncertain"] = False
        elif method == "FIXG":
            o["d_nom"] = int(max(1, round(pn)))
            o["d_up"] = int(max(o["d_nom"], round(pn * 1.15)))
            o["uncertain"] = True
        elif method == "NOCONF":
            o["d_nom"] = int(max(1, round(pn)))
            o["d_up"] = int(max(o["d_nom"], round(max(pn, raw))))
            o["uncertain"] = True
        elif method == "NOML":
            gm = uq[tgt]["glob_med"] / 60.0
            gq = uq[tgt]["glob_q"][alpha] / 60.0
            o["d_nom"] = int(max(1, round(gm)))
            o["d_up"] = int(max(o["d_nom"], round(gq)))
            o["uncertain"] = True
        else:  # CORDS / NOCCG / SAA share the conformal model
            o["d_nom"] = int(max(1, round(pn)))
            o["d_up"] = int(max(o["d_nom"], round(max(pn, up))))
            o["uncertain"] = True
    return win


def saa_scens(win, uq, n, rng):
    scens = [win.scenario(set())]
    for _ in range(n - 1):
        sc = win.scenario(set())
        for o in win.ops:
            if o["uncertain"]:
                tgt = "charge" if o["stage"] == 0 else "discharge"
                r = rng.choice(uq[tgt]["resid"]) / 60.0
                sc["d"][o["id"]] = int(max(1, round(o["d_nom"] + r)))
        scens.append(sc)
    return scens


def plan_for(win, method, uq, alpha, beta, tl, rng, lam=(1, 1)):
    K = len(win.uncertain_units())
    Gam = gamma_budget(K, alpha, beta) if K else 0
    tl_eff = tl * (1.0 + len(win.ops) / 18.0)      # scale with window size
    t0 = time.time()
    if method in ("DET", "P90", "ORACLE"):
        sol = solve_master(win, [win.scenario(set())], time_limit=tl_eff,
                           mode="single")
    elif method == "SAA":
        hint = solve_master(win, [win.scenario(set())],
                            time_limit=min(0.5, tl), mode="single")
        sol = solve_master(win, saa_scens(win, uq, 6, rng),
                           time_limit=tl_eff * 2, mode="saa", hint=hint)
    elif method == "NOCCG":
        sol, _ = ccg_solve(win, Gam, time_limit=tl_eff, max_add=0, lam=lam)
    else:  # CORDS, FIXG, NOCONF, NOML
        sol, _ = ccg_solve(win, Gam, time_limit=tl_eff, max_add=2, lam=lam)
        if sol is not None:
            sol = polish(win, sol, Gam, lam=lam,
                         budget_s=min(6.0, 0.25 * len(win.ops)))
    return sol, Gam, time.time() - t0


# ---------------------------------------------------------------- audit
def audit_plan(win_audit, sol, Gamma):
    nom, _, _ = evaluate_fixed(win_audit, sol["assign"], sol["order"],
                               win_audit.scenario(set()))
    wc, _, exact = adversary(win_audit, sol["assign"], sol["order"], Gamma)
    return nom, wc, exact


def realized_cost(win_audit, sol, aux):
    sc = win_audit.scenario(set())
    for o in win_audit.ops:
        sc["d"][o["id"]] = int(max(1, round(aux[o["id"]]["true"])))
    twt, Cj, _ = evaluate_fixed(win_audit, sol["assign"], sol["order"], sc)
    lates = sum(1 for j, dd in win_audit.jobs.items()
                if j in Cj and Cj[j] > dd["due"])
    return twt, lates


METHODS = ("ORACLE", "DET", "P90", "SAA", "FIXG", "NOCONF", "NOML", "NOCCG", "CORDS")


def bench(snaps, uq, alpha=0.1, beta=0.1, tl=1.0, methods=METHODS,
          out_csv=None, tag="", lam=(1, 1)):
    rng = np.random.default_rng(7)
    rows = []
    for wix, snap in enumerate(snaps):
        aux = snap["aux"]
        win_a = make_variant(snap, "CORDS", alpha, uq)     # audit set
        K = len(win_a.uncertain_units())
        Gam = gamma_budget(K, alpha, beta) if K else 0
        exceed = sum(1 for o in win_a.ops
                     if o["uncertain"] and aux[o["id"]]["true"] > o["d_up"] + 0.5)
        for meth in methods:
            win_m = make_variant(snap, meth, alpha, uq)
            sol, Gam_own, st = plan_for(win_m, meth, uq, alpha, beta, tl, rng, lam=lam)
            if sol is None:
                continue
            nom, wc_aud, exact = audit_plan(win_a, sol, Gam)
            real, lates = realized_cost(win_a, sol, aux)
            row = dict(tag=tag, w=wix, seed=snap["seed"], t=snap["t"],
                       method=meth, K=K, Gamma=Gam, exceed=exceed,
                       n_ops=len(win_a.ops), n_jobs=len(win_a.jobs),
                       nom_twt=nom, wc_audit=wc_aud, wc_exact=int(exact),
                       real_twt=real, real_late=lates, solve_s=st)
            if meth in ("CORDS", "NOCCG", "FIXG", "NOCONF", "NOML"):
                wc_self, _, _ = adversary(win_m, sol["assign"], sol["order"], Gam_own)
                row["wc_self"] = wc_self
                row["cert_viol"] = int(real > wc_self + 0.5)
            rows.append(row)
        if out_csv and (wix + 1) % 10 == 0:
            pd.DataFrame(rows).to_csv(out_csv, index=False)
    df = pd.DataFrame(rows)
    if out_csv:
        df.to_csv(out_csv, index=False)
    return df
