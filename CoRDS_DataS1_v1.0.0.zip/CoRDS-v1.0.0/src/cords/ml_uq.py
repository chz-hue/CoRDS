"""
ml_uq.py
Quantile gradient boosting + (Mondrian) split-conformal calibration of
processing-time uncertainty sets, and the coverage->budget calibration rule.

Prediction targets (real data, NASA PCoE):
  - charge ops   -> stage-1 formation-verification durations
  - discharge ops-> stage-3 EOL capacity-test durations
"""
import numpy as np
from cords.paths import DATA_PROC_DIR, RESULTS_DIR
import pandas as pd
from dataclasses import dataclass, field
from sklearn.ensemble import GradientBoostingRegressor
from scipy.stats import binom

FEATURES = ["ambient_T", "dis_I", "v_cut", "soh", "prev_cap",
            "n_prior", "roll_mean3", "roll_std5", "last_dur"]
RS = 12345


def temp_group(t):
    if t <= 10:
        return "cold(4C)"
    if t <= 30:
        return "room(22-24C)"
    return "hot(43-44C)"


# ----------------------------------------------------------------------
def _gbr(q):
    return GradientBoostingRegressor(loss="quantile", alpha=q, n_estimators=250,
                                     max_depth=3, learning_rate=0.05,
                                     subsample=0.9, random_state=RS)


@dataclass
class CQRModel:
    """Quantile GBR with split-conformal calibration (two-sided CQR and
    one-sided upper), optionally Mondrian (group-conditional) on temp group."""
    alpha: float = 0.1
    mondrian: bool = True
    q_lo_: object = None
    q_md_: object = None
    q_hi_: object = None
    c_two_: dict = field(default_factory=dict)   # group -> correction (two-sided)
    c_up_: dict = field(default_factory=dict)    # group -> correction (one-sided upper)
    groups_: list = field(default_factory=list)

    def fit(self, X_tr, y_tr, X_cal, y_cal, g_cal):
        a = self.alpha
        self.q_lo_ = _gbr(a / 2).fit(X_tr, y_tr)
        self.q_md_ = _gbr(0.5).fit(X_tr, y_tr)
        self.q_hi_ = _gbr(1 - a / 2).fit(X_tr, y_tr)
        lo = self.q_lo_.predict(X_cal)
        hi = self.q_hi_.predict(X_cal)
        s_two = np.maximum(lo - y_cal, y_cal - hi)          # CQR score
        s_up = y_cal - hi                                    # one-sided upper score
        self.groups_ = sorted(set(g_cal)) if self.mondrian else ["ALL"]
        gc = np.asarray(g_cal) if self.mondrian else np.array(["ALL"] * len(y_cal))
        for g in self.groups_ + ["ALL"]:
            m = (gc == g) if g != "ALL" else np.ones(len(y_cal), bool)
            n = int(m.sum())
            if n < 30 and g != "ALL":
                continue
            k = int(np.ceil((n + 1) * (1 - a)))
            k = min(k, n)
            self.c_two_[g] = float(np.sort(s_two[m])[k - 1])
            self.c_up_[g] = float(np.sort(s_up[m])[k - 1])
        return self

    def _corr(self, table, g):
        return np.array([table.get(gi, table["ALL"]) for gi in g])

    def interval(self, X, g):
        lo = self.q_lo_.predict(X) - self._corr(self.c_two_, g)
        hi = self.q_hi_.predict(X) + self._corr(self.c_two_, g)
        return np.maximum(lo, 1.0), hi

    def upper(self, X, g):
        """calibrated one-sided upper bound u with P(y<=u)>=1-alpha"""
        return self.q_hi_.predict(X) + self._corr(self.c_up_, g)

    def median(self, X):
        return self.q_md_.predict(X)


# ----------------------------------------------------------------------
class OnlineUpper:
    """Online adaptive calibration of the one-sided upper bound
    (online (sub)gradient descent on the pinball loss of the correction term,
    in the spirit of adaptive conformal inference).  At each completed
    operation with feature x and realized duration y:
        u(x) = q_hi(x) + c ;  c <- c + eta * ( 1{y > u(x)} - alpha ) * scale
    Long-run miscoverage tracks alpha even under distribution shift."""

    def __init__(self, cqr: "CQRModel", alpha=0.1, eta=0.05):
        self.cqr = cqr
        self.alpha = alpha
        self.eta = eta
        # initialize from the (global) split-conformal correction and score scale
        self.c = cqr.c_up_.get("ALL", 0.0)
        scores = list(cqr.c_up_.values())
        self.scale = max(60.0, abs(self.c) if self.c else 60.0)

    def set_scale(self, s):
        self.scale = max(60.0, float(s))

    def upper(self, X, g=None):
        return self.cqr.q_hi_.predict(X) + self.c

    def median(self, X):
        return self.cqr.median(X)

    def update(self, x_row, y):
        u = float(self.cqr.q_hi_.predict(x_row.reshape(1, -1))[0] + self.c)
        err = 1.0 if y > u else 0.0
        self.c += self.eta * (err - self.alpha) * self.scale
        return err


# ----------------------------------------------------------------------
def gamma_budget(K, alpha, beta):
    """Smallest integer Gamma with P(Bin(K, alpha) > Gamma) <= beta.

    This evaluates the binomial quantile behind Definition 1 of the paper.
    The probabilistic reading (paper, Proposition 2) additionally ASSUMES
    that bound-exceedance indicators are independent across the window's
    K uncertain operations, each with marginal exceedance probability at
    most alpha; only under those assumptions does "more than Gamma
    exceedances" have probability at most beta. Computing Gamma here does
    not by itself establish that guarantee for any given data set -- see
    the paper's "Limitations of the study" for when the assumption is
    plausible and how it can fail."""
    if K <= 0:
        return 0
    g = int(binom.ppf(1 - beta, K, alpha))
    while binom.sf(g, K, alpha) > beta:
        g += 1
    return int(min(g, K))


# ----------------------------------------------------------------------
def make_splits(ops, mode, seed=RS):
    """Return boolean masks (train, calib, test) over rows of `ops`."""
    rng = np.random.default_rng(seed)
    ops = ops.reset_index(drop=True)
    if mode == "op":           # random op-level split (exchangeable)
        idx = rng.permutation(len(ops))
        n = len(ops)
        tr = np.zeros(n, bool); ca = np.zeros(n, bool); te = np.zeros(n, bool)
        tr[idx[: int(0.5 * n)]] = True
        ca[idx[int(0.5 * n): int(0.75 * n)]] = True
        te[idx[int(0.75 * n):]] = True
        return tr, ca, te
    if mode == "cell":         # cell-level split, stratified by temp group
        cells = ops.groupby("battery")["ambient_T"].first().reset_index()
        cells["g"] = cells.ambient_T.map(temp_group)
        tr_c, ca_c, te_c = [], [], []
        for g, gg in cells.groupby("g"):
            ids = list(gg.battery)
            rng.shuffle(ids)
            n = len(ids)
            n_tr = max(1, int(round(0.5 * n)))
            n_ca = max(1, int(round(0.25 * n)))
            tr_c += ids[:n_tr]; ca_c += ids[n_tr:n_tr + n_ca]; te_c += ids[n_tr + n_ca:]
        return (ops.battery.isin(tr_c).values, ops.battery.isin(ca_c).values,
                ops.battery.isin(te_c).values)
    if mode == "shift":        # train/calibrate on room+hot cells, test on cold cells
        g = ops.ambient_T.map(temp_group)
        cold = (g == "cold(4C)").values
        warm_ops = ops[~cold]
        cells = warm_ops.battery.unique().tolist()
        rng.shuffle(cells)
        n_ca = max(2, int(round(0.33 * len(cells))))
        ca_c = set(cells[:n_ca])
        ca = ops.battery.isin(ca_c).values & ~cold
        tr = ~cold & ~ca
        return tr, ca, cold
    raise ValueError(mode)


# ----------------------------------------------------------------------
# RQ1 evaluation: coverage & width of upper bounds / intervals
def eval_uq(ops, mode, alpha=0.1, seed=RS):
    ops = ops.dropna(subset=FEATURES + ["y_duration_s"]).reset_index(drop=True)
    tr, ca, te = make_splits(ops, mode, seed)
    X = ops[FEATURES].values.astype(float)
    y = ops["y_duration_s"].values.astype(float)
    g = ops.ambient_T.map(temp_group).values

    rows = []

    def add(name, up, lo=None, hi=None):
        cov_up = float(np.mean(y[te] <= up))
        r = dict(split=mode, method=name, alpha=alpha,
                 cov_upper=cov_up,
                 margin_upper=float(np.mean(up - np.median(y[tr]) * 0)) if False else float(np.mean(up - yhat_med)),
                 )
        # per-group minimum upper coverage (conditional validity)
        covs = [float(np.mean((y[te] <= up)[g[te] == gg])) for gg in set(g[te]) if (g[te] == gg).sum() > 20]
        r["cov_upper_min_group"] = float(min(covs)) if covs else np.nan
        if lo is not None:
            r["cov_two"] = float(np.mean((y[te] >= lo) & (y[te] <= hi)))
            r["width_two"] = float(np.mean(hi - lo))
        rows.append(r)

    # ---- ours: CQR (Mondrian)
    m = CQRModel(alpha=alpha, mondrian=True).fit(X[tr], y[tr], X[ca], y[ca], g[ca])
    yhat_med = m.median(X[te])
    lo, hi = m.interval(X[te], g[te])
    add("CQR-Mondrian (ours)", m.upper(X[te], g[te]), lo, hi)

    # ---- ablation: CQR global (no Mondrian)
    m2 = CQRModel(alpha=alpha, mondrian=False).fit(X[tr], y[tr], X[ca], y[ca], g[ca])
    lo2, hi2 = m2.interval(X[te], g[te])
    add("CQR-global", m2.upper(X[te], g[te]), lo2, hi2)

    # ---- ablation: raw quantile regression, no conformal
    add("QR (no conformal)", m.q_hi_.predict(X[te]),
        m.q_lo_.predict(X[te]), m.q_hi_.predict(X[te]))

    # ---- baseline: global empirical quantile (no features)
    q_up = np.quantile(y[np.concatenate([np.where(tr)[0], np.where(ca)[0]])], 1 - alpha)
    q_lo = np.quantile(y[np.concatenate([np.where(tr)[0], np.where(ca)[0]])], alpha / 2)
    q_hi2 = np.quantile(y[np.concatenate([np.where(tr)[0], np.where(ca)[0]])], 1 - alpha / 2)
    add("Empirical quantile", np.full(te.sum(), q_up),
        np.full(te.sum(), q_lo), np.full(te.sum(), q_hi2))

    # ---- baseline: Gaussian residual (homoscedastic) around GBR mean
    gm = GradientBoostingRegressor(n_estimators=250, max_depth=3, learning_rate=0.05,
                                   subsample=0.9, random_state=RS).fit(X[tr], y[tr])
    res = y[ca] - gm.predict(X[ca])
    from scipy.stats import norm
    z1 = norm.ppf(1 - alpha)
    z2 = norm.ppf(1 - alpha / 2)
    mu, s = float(np.mean(res)), float(np.std(res))
    pr = gm.predict(X[te])
    add("Gaussian residual", pr + mu + z1 * s, pr + mu - z2 * s, pr + mu + z2 * s)

    return pd.DataFrame(rows), m


if __name__ == "__main__":
    import os
    out = []
    for target, f in [("charge", "ops_charge.csv"), ("discharge", "ops_discharge.csv")]:
        ops = pd.read_csv(DATA_PROC_DIR / f)
        for mode in ["op", "cell", "shift"]:
            df, _ = eval_uq(ops, mode)
            df.insert(0, "target", target)
            out.append(df)
            print(df[["target", "split", "method", "cov_upper", "cov_upper_min_group", "cov_two", "width_two"]].to_string(index=False))
    res = pd.concat(out, ignore_index=True)
    res.to_csv(RESULTS_DIR / "rq1_uq.csv", index=False)

    # ---- online adaptation under regime shift (sequential replay, cold cells)
    rows2 = []
    for target, f in [("charge", "ops_charge.csv"), ("discharge", "ops_discharge.csv")]:
        ops = pd.read_csv(DATA_PROC_DIR / f).dropna(subset=FEATURES + ["y_duration_s"]).reset_index(drop=True)
        tr, ca, te = make_splits(ops, "shift")
        X = ops[FEATURES].values.astype(float); y = ops.y_duration_s.values
        g = ops.ambient_T.map(temp_group).values
        m = CQRModel(alpha=0.1, mondrian=False).fit(X[tr], y[tr], X[ca], y[ca], g[ca])
        # replay cold ops in chronological order (battery, seq)
        cold = ops[te].sort_values(["battery", "seq"]).index.values
        # scale = MAD of calib upper-scores
        sc = np.abs(y[ca] - m.q_hi_.predict(X[ca]))
        for eta, name in [(0.0, "static CQR"), (0.05, "online-adaptive (ours)")]:
            ou = OnlineUpper(m, alpha=0.1, eta=eta)
            ou.set_scale(np.median(sc) * 3)
            errs, margins = [], []
            for i in cold:
                u = float(ou.upper(X[i].reshape(1, -1))[0])
                errs.append(1.0 if y[i] > u else 0.0)
                margins.append(u - y[i])
                ou.update(X[i], y[i])
            n = len(errs)
            h2 = n // 2
            rows2.append(dict(target=target, method=name,
                              cov_all=1 - np.mean(errs),
                              cov_secondhalf=1 - np.mean(errs[h2:]),
                              mean_margin=float(np.mean(margins))))
            print(rows2[-1])
    pd.DataFrame(rows2).to_csv(RESULTS_DIR / "rq1_online.csv", index=False)
    # budget rule sanity
    for K in [12, 24, 36]:
        print(f"K={K}: Gamma(a=0.1,b=0.1)={gamma_budget(K,0.1,0.1)}  Gamma(a=0.2,b=0.1)={gamma_budget(K,0.2,0.1)}")
