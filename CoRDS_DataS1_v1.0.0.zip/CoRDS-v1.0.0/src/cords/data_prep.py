"""
data_prep.py
Parse the NASA PCoE Li-ion Battery Aging Dataset (34 cells, .mat files) into a
per-cycle operation table used to instantiate REAL processing times for the
formation-verification (charge) and EOL capacity-test (discharge) operations
in battery pack manufacturing scheduling.

Output: results/cycles.csv  (one row per charge/discharge cycle)
        results/ops_charge.csv / ops_discharge.csv  (ML-ready, leakage-free features)
"""
import os
import glob
import numpy as np
from cords.paths import DATA_RAW_DIR, DATA_PROC_DIR
import pandas as pd
from scipy.io import loadmat

DATA_DIR = str(DATA_RAW_DIR)  # override: CORDS_DATA_RAW or --data-dir
OUT_DIR = str(DATA_PROC_DIR)
os.makedirs(OUT_DIR, exist_ok=True)


def parse_battery(path):
    name = os.path.basename(path).replace(".mat", "")
    try:
        mat = loadmat(path, simplify_cells=False)
    except Exception as e:
        print(f"[skip] {name}: cannot load ({e})")
        return []
    if name not in mat:
        print(f"[skip] {name}: key missing")
        return []
    cycles = mat[name][0, 0]["cycle"][0]
    rows = []
    for i in range(len(cycles)):
        c = cycles[i]
        try:
            ctype = str(c["type"][0])
        except Exception:
            continue
        if ctype not in ("charge", "discharge"):
            continue  # skip impedance
        try:
            amb = float(np.asarray(c["ambient_temperature"]).squeeze())
        except Exception:
            amb = np.nan
        try:
            tvec = np.asarray(c["time"]).squeeze()
            start = pd.Timestamp(int(tvec[0]), int(tvec[1]), int(tvec[2]),
                                 int(tvec[3]), int(tvec[4]), int(round(float(tvec[5]))) % 60)
        except Exception:
            start = pd.NaT
        d = c["data"]
        try:
            tt = np.asarray(d["Time"][0, 0]).squeeze()
            dur = float(np.nanmax(tt))
        except Exception:
            continue
        cap = np.nan
        i_med = np.nan
        v_end = np.nan
        try:
            if ctype == "discharge":
                cap = float(np.asarray(d["Capacity"][0, 0]).squeeze())
                cur = np.asarray(d["Current_measured"][0, 0]).squeeze()
                i_med = float(np.nanmedian(np.abs(cur)))
                vv = np.asarray(d["Voltage_measured"][0, 0]).squeeze()
                v_end = float(vv[np.nanargmax(tt)]) if len(vv) else np.nan
            else:
                cur = np.asarray(d["Current_measured"][0, 0]).squeeze()
                i_med = float(np.nanmedian(np.abs(cur[: max(3, len(cur) // 4)])))
        except Exception:
            pass
        rows.append(dict(battery=name, seq=i, type=ctype, ambient_T=amb,
                         start=start, duration_s=dur, capacity=cap,
                         i_level=i_med, v_end=v_end))
    print(f"[ok] {name}: {len(rows)} charge/discharge cycles")
    return rows


def main():
    files = sorted(glob.glob(os.path.join(DATA_DIR, "B*.mat")))
    all_rows = []
    for f in files:
        all_rows += parse_battery(f)
    df = pd.DataFrame(all_rows)
    df = df.sort_values(["battery", "seq"]).reset_index(drop=True)
    df.to_csv(os.path.join(OUT_DIR, "cycles.csv"), index=False)
    print("total rows:", len(df))
    print(df.groupby(["type"])['duration_s'].describe())

    # ---------------- build ML-ready op tables (no leakage) ----------------
    # per battery protocol descriptors from DISCHARGE data (set by test plan,
    # hence known a priori): median discharge current, cutoff voltage
    prot = (df[df.type == "discharge"].groupby("battery")
            .agg(dis_I=("i_level", "median"), v_cut=("v_end", "median")).reset_index())
    df = df.merge(prot, on="battery", how="left")

    def build_ops(dfb, optype):
        """Features known BEFORE the operation starts."""
        out = []
        for b, g in dfb[dfb.type == optype].groupby("battery"):
            g = g.sort_values("seq").reset_index(drop=True)
            # last observed discharge capacity before this op (SOH proxy)
            caps = dfb[(dfb.battery == b) & (dfb.type == "discharge")][["seq", "capacity"]]
            for k in range(len(g)):
                r = g.loc[k]
                prev_caps = caps[caps.seq < r.seq]["capacity"].dropna()
                prev_cap = prev_caps.iloc[-1] if len(prev_caps) else np.nan
                cap0 = caps["capacity"].dropna().iloc[0] if caps["capacity"].notna().any() else np.nan
                past = g.loc[: k - 1, "duration_s"] if k > 0 else pd.Series(dtype=float)
                out.append(dict(
                    battery=b, seq=int(r.seq), op_idx=k,
                    ambient_T=r.ambient_T, dis_I=r.dis_I, v_cut=r.v_cut,
                    prev_cap=prev_cap, cap0=cap0,
                    soh=(prev_cap / cap0 if (np.isfinite(prev_cap) and np.isfinite(cap0) and cap0 > 0) else np.nan),
                    n_prior=k,
                    roll_mean3=past.tail(3).mean() if k > 0 else np.nan,
                    roll_std5=past.tail(5).std() if k > 1 else np.nan,
                    last_dur=past.iloc[-1] if k > 0 else np.nan,
                    y_duration_s=float(r.duration_s),
                ))
        return pd.DataFrame(out)

    ops_c = build_ops(df, "charge")
    ops_d = build_ops(df, "discharge")

    # cleaning: drop clearly-invalid records (documented in the paper):
    #  - charge ops shorter than 30 min or longer than 6 h (aborted/instrument restarts)
    #  - discharge ops shorter than 10 min or longer than 3 h
    n0c, n0d = len(ops_c), len(ops_d)
    ops_c = ops_c[(ops_c.y_duration_s >= 1800) & (ops_c.y_duration_s <= 21600)]
    ops_d = ops_d[(ops_d.y_duration_s >= 600) & (ops_d.y_duration_s <= 10800)]
    # require SOH proxy & rolling history available (first 2 ops per cell dropped)
    ops_c = ops_c.dropna(subset=["soh", "roll_mean3", "last_dur"]).reset_index(drop=True)
    ops_d = ops_d.dropna(subset=["soh", "roll_mean3", "last_dur"]).reset_index(drop=True)
    print(f"charge ops: {n0c} -> {len(ops_c)} | discharge ops: {n0d} -> {len(ops_d)}")
    ops_c.to_csv(os.path.join(OUT_DIR, "ops_charge.csv"), index=False)
    ops_d.to_csv(os.path.join(OUT_DIR, "ops_discharge.csv"), index=False)
    print(ops_c.groupby("ambient_T")["y_duration_s"].describe())
    print(ops_d.groupby("ambient_T")["y_duration_s"].describe())


if __name__ == "__main__":
    main()
